function w(t,a,r=5e3){let n=t,s=null,e=null,u=!1;if(!("comm"in n||"widget_manager"in n))return()=>{};function c(){return"comm"in n?n.comm!=null:n.widget_manager!=null}return s=setInterval(()=>{u||(!c()&&!e?e=setTimeout(()=>{!c()&&!u&&(u=!0,a()),e=null},r):c()&&e&&(clearTimeout(e),e=null))},2e3),()=>{s&&(clearInterval(s),s=null),e&&(clearTimeout(e),e=null)}}function b(t,a,r){return getComputedStyle(t).getPropertyValue(a).trim()||r}function E(t){let a=globalThis,r=a.AudioContext||a.webkitAudioContext;if(!r)return null;try{return new r(t)}catch{try{return new r}catch{return null}}}function h(t,a){t.style.cursor="pointer",t.title="Double-click to edit",t.addEventListener("dblclick",()=>{let r=!1,n=document.createElement("input");n.type="text",n.className=a.className??"nbplay-inline-edit",n.value=a.getValue(),n.style.width=Math.max(t.offsetWidth+8,48)+"px",t.replaceWith(n),n.focus(),n.select();function s(){if(r)return;r=!0;let e=a.parse(n.value.trim());e!==null&&a.apply(e),n.replaceWith(t),a.sync()}n.addEventListener("keydown",e=>{e.key==="Enter"&&(e.preventDefault(),s()),e.key==="Escape"&&(e.preventDefault(),r||(r=!0,n.replaceWith(t),a.sync()))}),n.addEventListener("blur",s)})}function q(t){if(!t||!t.byteLength)return null;if(t instanceof DataView){let a=t.byteLength/4,r=new Float32Array(a);for(let n=0;n<a;n++)r[n]=t.getFloat32(n*4,!0);return r}if(t.buffer instanceof ArrayBuffer){let a=t;return new Float32Array(a.buffer.slice(a.byteOffset,a.byteOffset+a.byteLength))}return t instanceof ArrayBuffer?new Float32Array(t):null}var g=20,L=8e3,C=Math.log(L/g);function S(t){return Math.log(Math.max(g,Math.min(L,t))/g)/C}function _(t){return g*Math.exp(C*Math.max(0,Math.min(1,t)))}function F(t){return t>=1e3?(t/1e3).toFixed(2)+" kHz":t.toFixed(1)+" Hz"}function N(t,a){let r=window.devicePixelRatio||1,n=t.clientWidth||600,s=t.clientHeight||128;t.width=n*r,t.height=s*r;let e=t.getContext("2d");e.scale(r,r);let u=b(t,"--jp-layout-color0","#080812"),l=b(t,"--jp-brand-color1","#00d4ff"),c=b(t,"--jp-ui-font-color3","#64648a");if(e.fillStyle=u,e.fillRect(0,0,n,s),e.strokeStyle=c,e.globalAlpha=.35,e.lineWidth=1,e.setLineDash([4,4]),e.beginPath(),e.moveTo(0,s/2),e.lineTo(n,s/2),e.stroke(),e.setLineDash([]),e.globalAlpha=.15,e.beginPath(),e.moveTo(0,s*.25),e.lineTo(n,s*.25),e.moveTo(0,s*.75),e.lineTo(n,s*.75),e.stroke(),e.globalAlpha=1,!a||a.length===0)return;let p=a.length/n;e.strokeStyle=l,e.globalAlpha=.25,e.lineWidth=6,e.lineCap="round",e.lineJoin="round",e.beginPath();for(let i=0;i<n;i++){let y=(1-a[Math.min(Math.floor(i*p),a.length-1)])*s/2;i===0?e.moveTo(i,y):e.lineTo(i,y)}e.stroke(),e.globalAlpha=1,e.strokeStyle=l,e.lineWidth=2,e.beginPath();for(let i=0;i<n;i++){let y=(1-a[Math.min(Math.floor(i*p),a.length-1)])*s/2;i===0?e.moveTo(i,y):e.lineTo(i,y)}e.stroke()}function H(){let t=null,a=null,r=null;return{start(n,s,e,u){if(this.stop(),t=E({sampleRate:u}),!t)return!1;if(r=t.createGain(),r.gain.value=e,r.connect(t.destination),n==="noise"){let l=t.createBuffer(1,u*2,u),c=l.getChannelData(0);for(let i=0;i<c.length;i++)c[i]=Math.random()*2-1;let p=t.createBufferSource();p.buffer=l,p.loop=!0,p.connect(r),p.start(),a=p}else{let l=t.createOscillator();l.type=n==="saw"?"sawtooth":n,l.frequency.value=s,l.connect(r),l.start(),a=l}return!0},stop(){if(a){try{a.stop()}catch{}a.disconnect(),a=null}r&&(r.disconnect(),r=null),t&&(t.close(),t=null)},setFrequency(n){a&&a.frequency&&t&&a.frequency.setTargetAtTime(n,t.currentTime,.01)},setAmplitude(n){r&&t&&r.gain.setTargetAtTime(n,t.currentTime,.01)}}}function B({model:t,el:a}){let r=H(),n=document.createElement("div");n.className="nbplay-synth",n.innerHTML=`
    <div class="nbplay-header">
      <h3>nbplay</h3>
      <span class="nbplay-badge">synth</span>
    </div>

    <div class="nbplay-waveform-container">
      <canvas class="nbplay-waveform"></canvas>
    </div>

    <div class="nbplay-osc-selector">
      <span class="nbplay-label">Oscillator</span>
      <div class="nbplay-osc-buttons">
        <button class="nbplay-osc-btn" data-type="sine">Sine</button>
        <button class="nbplay-osc-btn" data-type="square">Square</button>
        <button class="nbplay-osc-btn" data-type="saw">Saw</button>
        <button class="nbplay-osc-btn" data-type="noise">Noise</button>
      </div>
    </div>

    <div class="nbplay-params">
      <div class="nbplay-param">
        <span class="nbplay-label">Frequency</span>
        <input type="range" class="nbplay-freq" min="0" max="1" step="0.001" />
        <span class="nbplay-value nbplay-freq-val"></span>
      </div>
      <div class="nbplay-param">
        <span class="nbplay-label">Amplitude</span>
        <input type="range" class="nbplay-amp" min="0" max="1" step="0.01" />
        <span class="nbplay-value nbplay-amp-val"></span>
      </div>
    </div>

    <div class="nbplay-transport">
      <button class="nbplay-play-btn"></button>
      <span class="nbplay-info"></span>
    </div>
  `,a.appendChild(n);let s=n.querySelector(".nbplay-waveform"),e=n.querySelectorAll(".nbplay-osc-btn"),u=n.querySelector(".nbplay-freq"),l=n.querySelector(".nbplay-freq-val"),c=n.querySelector(".nbplay-amp"),p=n.querySelector(".nbplay-amp-val"),i=n.querySelector(".nbplay-play-btn"),y=n.querySelector(".nbplay-info");function x(){let o=t.get("oscillator_type");e.forEach(T=>T.classList.toggle("active",T.dataset.type===o));let f=o==="noise";u.disabled=f}function m(){let o=t.get("frequency");u.value=String(S(o)),l.textContent=F(o)}function v(){let o=t.get("amplitude");c.value=String(o),p.textContent=o.toFixed(2)}function d(){let o=t.get("is_playing");i.textContent=o?"\u25A0  Stop":"\u25B6  Play",i.classList.toggle("playing",o)}h(l,{getValue:()=>String(t.get("frequency")),parse:o=>{let f=parseFloat(o);return isNaN(f)?null:(o.toLowerCase().includes("k")&&(f*=1e3),Math.max(20,Math.min(8e3,Math.round(f*10)/10)))},apply:o=>{t.set("frequency",o),t.save_changes(),r.setFrequency(o)},sync:m}),h(p,{getValue:()=>String(t.get("amplitude")),parse:o=>{let f=parseFloat(o);return isNaN(f)?null:Math.max(0,Math.min(1,Math.round(f*100)/100))},apply:o=>{t.set("amplitude",o),t.save_changes(),r.setAmplitude(o)},sync:v});function M(){y.textContent=t.get("sample_rate")+" Hz"}function A(){let o=t.get("waveform");N(s,q(o))}e.forEach(o=>o.addEventListener("click",()=>{t.set("oscillator_type",o.dataset.type),t.save_changes(),t.get("is_playing")&&r.start(o.dataset.type,t.get("frequency"),t.get("amplitude"),t.get("sample_rate"))})),u.addEventListener("input",()=>{let o=Math.round(_(parseFloat(u.value))*10)/10;t.set("frequency",o),t.save_changes(),r.setFrequency(o)}),c.addEventListener("input",()=>{let o=Math.round(parseFloat(c.value)*100)/100;t.set("amplitude",o),t.save_changes(),r.setAmplitude(o)}),i.addEventListener("click",()=>{t.set("is_playing",!t.get("is_playing")),t.save_changes()}),t.on("change:oscillator_type",x),t.on("change:frequency",m),t.on("change:amplitude",v),t.on("change:is_playing",()=>{d(),t.get("is_playing")?r.start(t.get("oscillator_type"),t.get("frequency"),t.get("amplitude"),t.get("sample_rate"))||(t.set("is_playing",!1),t.save_changes(),d()):r.stop()}),t.on("change:sample_rate",M),t.on("change:waveform",A),t.set("is_playing",!1),x(),m(),v(),d(),M(),requestAnimationFrame(A);let k=w(t,()=>{t.set("is_playing",!1),r.stop(),d()});return()=>{k(),r.stop()}}var I={render:B};export{I as default};
//# sourceMappingURL=widget.js.map
