var S=8;function E(e){if(!e||e.length===0)return"";let s=e[0],t=s&240,n=(s&15)+1;if(t===144&&e.length>=3)return`NoteOn  ch=${n} note=${e[1]} vel=${e[2]}`;if(t===128&&e.length>=3)return`NoteOff ch=${n} note=${e[1]} vel=${e[2]}`;if(t===176&&e.length>=3)return`CC      ch=${n} ctrl=${e[1]} val=${e[2]}`;if(t===192&&e.length>=2)return`PgmChg  ch=${n} pgm=${e[1]}`;if(t===224&&e.length>=3){let i=e[1]|e[2]<<7;return`Bend    ch=${n} val=${i}`}return s===248?"Clock":s===250?"Start":s===252?"Stop":s===251?"Continue":`Raw [${Array.from(e).map(i=>i.toString(16).padStart(2,"0")).join(" ")}]`}function L(){let e=null,s=null,t=null;return{async requestAccess(){if(e)return e;if(!navigator.requestMIDIAccess)return null;try{return e=await navigator.requestMIDIAccess({sysex:!1}),e}catch{return null}},getInputPorts(){if(!e)return[];let n=[];return e.inputs.forEach(i=>{n.push({id:i.id,name:i.name||"(unnamed)",state:i.state})}),n},connectInput(n,i){if(this.disconnectInput(),!e)return;let c=e.inputs.get(n);c&&(t=r=>i(r.data,r.timeStamp),c.addEventListener("midimessage",t),s=c)},disconnectInput(){s&&t&&s.removeEventListener("midimessage",t),s=null,t=null},getActivePortId(){return s?s.id:null}}}function _({model:e,el:s}){let t=L(),n=document.createElement("div");n.className="nbplay-settings",n.innerHTML=`
    <div class="nbplay-header">
      <h3>nbplay</h3>
      <span class="nbplay-badge">settings</span>
    </div>

    <div class="nbplay-section">
      <div class="nbplay-section-title">
        <span class="nbplay-section-icon">\u266B</span> Audio Output
      </div>
      <div class="nbplay-setting-row">
        <span class="nbplay-label">Sample Rate</span>
        <select class="nbplay-select nbplay-sr-select">
          <option value="22050">22050 Hz</option>
          <option value="44100">44100 Hz</option>
          <option value="48000">48000 Hz</option>
          <option value="96000">96000 Hz</option>
        </select>
      </div>
      <div class="nbplay-setting-row">
        <span class="nbplay-label">Channels</span>
        <select class="nbplay-select nbplay-ch-select">
          <option value="1">Mono</option>
          <option value="2">Stereo</option>
        </select>
      </div>
      <div class="nbplay-setting-row">
        <span class="nbplay-label">Buffer Size</span>
        <select class="nbplay-select nbplay-buf-select">
          <option value="128">128</option>
          <option value="256">256</option>
          <option value="512">512</option>
          <option value="1024">1024</option>
          <option value="2048">2048</option>
        </select>
      </div>
      <div class="nbplay-setting-row">
        <span class="nbplay-label">Device</span>
        <span class="nbplay-detail nbplay-audio-device">\u2014</span>
      </div>
    </div>

    <div class="nbplay-section">
      <div class="nbplay-section-title">
        <span class="nbplay-section-icon">\u{1D160}</span> MIDI Input
      </div>
      <div class="nbplay-setting-row">
        <span class="nbplay-label">Port</span>
        <select class="nbplay-select nbplay-midi-select">
          <option value="">Not connected</option>
        </select>
        <button class="nbplay-refresh-btn" title="Refresh MIDI ports">\u21BB</button>
      </div>
      <div class="nbplay-setting-row nbplay-midi-status-row">
        <span class="nbplay-label">Status</span>
        <span class="nbplay-detail nbplay-midi-status">Idle</span>
      </div>
      <div class="nbplay-midi-log-container">
        <div class="nbplay-midi-log-label">Activity</div>
        <div class="nbplay-midi-log"></div>
      </div>
    </div>
  `,s.appendChild(n);let i=n.querySelector(".nbplay-sr-select"),c=n.querySelector(".nbplay-ch-select"),r=n.querySelector(".nbplay-buf-select"),m=n.querySelector(".nbplay-audio-device"),v=n.querySelector(".nbplay-midi-select"),I=n.querySelector(".nbplay-refresh-btn"),b=n.querySelector(".nbplay-midi-status"),g=n.querySelector(".nbplay-midi-log");function d(){i.value=String(e.get("sample_rate")),c.value=String(e.get("channels")),r.value=String(e.get("buffer_size")),m.textContent=e.get("audio_device")||"Default"}function f(){let a=e.get("midi_port");v.value=a||"",b.textContent=a?"Connected":"Idle",b.classList.toggle("connected",!!a)}function M(a){let l=document.createElement("div");for(l.className="nbplay-midi-log-entry",l.textContent=a,g.prepend(l);g.children.length>S;)g.removeChild(g.lastChild)}async function h(){let a=await t.requestAccess();if(v.innerHTML='<option value="">Not connected</option>',a){let l=t.getInputPorts(),o=l.map(p=>p.name);e.set("available_midi_ports",o),e.save_changes(),l.forEach(p=>{let u=document.createElement("option");u.value=p.id,u.textContent=p.name,v.appendChild(u)})}f()}return i.addEventListener("change",()=>{e.set("sample_rate",parseInt(i.value,10)),e.save_changes()}),c.addEventListener("change",()=>{e.set("channels",parseInt(c.value,10)),e.save_changes()}),r.addEventListener("change",()=>{e.set("buffer_size",parseInt(r.value,10)),e.save_changes()}),I.addEventListener("click",()=>{h()}),v.addEventListener("change",()=>{let a=v.value;if(a){t.connectInput(a,(o,p)=>{let u=E(o);u&&M(u);let y=new Uint8Array(o.length+8);new DataView(y.buffer).setFloat64(0,p,!0),y.set(o,8),e.set("midi_event",new DataView(y.buffer)),e.save_changes()});let l=t.getInputPorts().find(o=>o.id===a);e.set("midi_port",l?l.name:a)}else t.disconnectInput(),e.set("midi_port","");e.save_changes()}),e.on("change:sample_rate",d),e.on("change:channels",d),e.on("change:buffer_size",d),e.on("change:audio_device",d),e.on("change:midi_port",f),d(),h(),()=>t.disconnectInput()}var w={render:_};export{w as default};
//# sourceMappingURL=settings.js.map
