function je(r,e,t=5e3){let n=r,i=null,s=null,a=!1;if(!("comm"in n||"widget_manager"in n))return()=>{};function l(){return"comm"in n?n.comm!=null:n.widget_manager!=null}return i=setInterval(()=>{a||(!l()&&!s?s=setTimeout(()=>{!l()&&!a&&(a=!0,e()),s=null},t):l()&&s&&(clearTimeout(s),s=null))},2e3),()=>{i&&(clearInterval(i),i=null),s&&(clearTimeout(s),s=null)}}function _(r,e,t){return getComputedStyle(r).getPropertyValue(e).trim()||t}function W(r){let e=globalThis,t=e.AudioContext||e.webkitAudioContext;if(!t)return null;try{return new t(r)}catch{try{return new t}catch{return null}}}function M(r){if(!r||!r.byteLength)return null;if(r instanceof DataView){let e=r.byteLength/4,t=new Float32Array(e);for(let n=0;n<e;n++)t[n]=r.getFloat32(n*4,!0);return t}if(r.buffer instanceof ArrayBuffer){let e=r;return new Float32Array(e.buffer.slice(e.byteOffset,e.byteOffset+e.byteLength))}return r instanceof ArrayBuffer?new Float32Array(r):null}function Tt(r){return Math.pow(10,r/20)}function me(r){if(r<=0)return"\u2212\u221E dB";let e=20*Math.log10(r);return e>=0?"+"+e.toFixed(1)+" dB":e.toFixed(1)+" dB"}function Ye(r){return Math.abs(r)<.01?"C":r<0?"L"+Math.round(Math.abs(r)*100):"R"+Math.round(r*100)}function qe(r){let e=r.replace(/\s*db\s*$/i,"").trim();if(e==="\u2212\u221E"||e==="-inf"||e==="-Infinity")return 0;let t=parseFloat(e);if(isNaN(t))return null;let n=Tt(t);return Math.max(0,Math.min(2,Math.round(n*1e3)/1e3))}function Rt(r){return r.replace(/[A-Z]/g,e=>"_"+e.toLowerCase())}function Ge(r,e,t,n){let i=t,s=(u,d)=>{let c=r.get(u);return d==="sessionId"?String(c||""):c};for(let[u,d]of Object.entries(n.config))i[d]=s(u,d);let a=!1,o=!1;function l(u,d){a=!0;try{for(let[c,p]of Object.entries(u))r.set(Rt(c),p)}finally{a=!1}d&&!o&&r.save_changes()}t.addEventListener("nbplay-set",u=>{l(u.detail.values,!0)}),t.addEventListener("nbplay-status",u=>{let{values:d,save:c}=u.detail;l(d,!!c)}),t.addEventListener("nbplay-request",u=>{let d=`${u.detail.name}_request`;r.set(d,(Number(r.get(d))||0)+1),o||r.save_changes()}),e.appendChild(t);let m={};for(let u of Object.values(n.status))m[u]=i[u];l(m,!1);for(let[u,d]of Object.entries(n.config))r.on(`change:${u}`,()=>{a||(i[d]=s(u,d))});for(let[u,d]of Object.entries(n.status))r.on(`change:${u}`,()=>{a||(i[d]=r.get(u))});if(n.command){let u=n.command===!0?"command":n.command,d=Number(r.get(u)?.nonce??-1);Number.isFinite(d)||(d=-1),r.on(`change:${u}`,()=>{let c=r.get(u)||{},p=Number(c.nonce);if(Number.isFinite(p)){if(p<=d)return;d=p}t.command?.(c)})}let b=je(r,()=>{o=!0,n.onDisconnect?.()});return()=>{b(),t.remove()}}var se=globalThis,ae=se.ShadowRoot&&(se.ShadyCSS===void 0||se.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,Je=Symbol(),Xe=new WeakMap,re=class{constructor(e,t,n){if(this._$cssResult$=!0,n!==Je)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=e,this.t=t}get styleSheet(){let e=this.o,t=this.t;if(ae&&e===void 0){let n=t!==void 0&&t.length===1;n&&(e=Xe.get(t)),e===void 0&&((this.o=e=new CSSStyleSheet).replaceSync(this.cssText),n&&Xe.set(t,e))}return e}toString(){return this.cssText}},Qe=r=>new re(typeof r=="string"?r:r+"",void 0,Je);var et=(r,e)=>{if(ae)r.adoptedStyleSheets=e.map(t=>t instanceof CSSStyleSheet?t:t.styleSheet);else for(let t of e){let n=document.createElement("style"),i=se.litNonce;i!==void 0&&n.setAttribute("nonce",i),n.textContent=t.cssText,r.appendChild(n)}},be=ae?r=>r:r=>r instanceof CSSStyleSheet?(e=>{let t="";for(let n of e.cssRules)t+=n.cssText;return Qe(t)})(r):r;var{is:Bt,defineProperty:Lt,getOwnPropertyDescriptor:Vt,getOwnPropertyNames:Dt,getOwnPropertySymbols:zt,getPrototypeOf:It}=Object,oe=globalThis,tt=oe.trustedTypes,Ot=tt?tt.emptyScript:"",Ft=oe.reactiveElementPolyfillSupport,K=(r,e)=>r,fe={toAttribute(r,e){switch(e){case Boolean:r=r?Ot:null;break;case Object:case Array:r=r==null?r:JSON.stringify(r)}return r},fromAttribute(r,e){let t=r;switch(e){case Boolean:t=r!==null;break;case Number:t=r===null?null:Number(r);break;case Object:case Array:try{t=JSON.parse(r)}catch{t=null}}return t}},it=(r,e)=>!Bt(r,e),nt={attribute:!0,type:String,converter:fe,reflect:!1,useDefault:!1,hasChanged:it};Symbol.metadata??=Symbol("metadata"),oe.litPropertyMetadata??=new WeakMap;var P=class extends HTMLElement{static addInitializer(e){this._$Ei(),(this.l??=[]).push(e)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(e,t=nt){if(t.state&&(t.attribute=!1),this._$Ei(),this.prototype.hasOwnProperty(e)&&((t=Object.create(t)).wrapped=!0),this.elementProperties.set(e,t),!t.noAccessor){let n=Symbol(),i=this.getPropertyDescriptor(e,n,t);i!==void 0&&Lt(this.prototype,e,i)}}static getPropertyDescriptor(e,t,n){let{get:i,set:s}=Vt(this.prototype,e)??{get(){return this[t]},set(a){this[t]=a}};return{get:i,set(a){let o=i?.call(this);s?.call(this,a),this.requestUpdate(e,o,n)},configurable:!0,enumerable:!0}}static getPropertyOptions(e){return this.elementProperties.get(e)??nt}static _$Ei(){if(this.hasOwnProperty(K("elementProperties")))return;let e=It(this);e.finalize(),e.l!==void 0&&(this.l=[...e.l]),this.elementProperties=new Map(e.elementProperties)}static finalize(){if(this.hasOwnProperty(K("finalized")))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(K("properties"))){let t=this.properties,n=[...Dt(t),...zt(t)];for(let i of n)this.createProperty(i,t[i])}let e=this[Symbol.metadata];if(e!==null){let t=litPropertyMetadata.get(e);if(t!==void 0)for(let[n,i]of t)this.elementProperties.set(n,i)}this._$Eh=new Map;for(let[t,n]of this.elementProperties){let i=this._$Eu(t,n);i!==void 0&&this._$Eh.set(i,t)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(e){let t=[];if(Array.isArray(e)){let n=new Set(e.flat(1/0).reverse());for(let i of n)t.unshift(be(i))}else e!==void 0&&t.push(be(e));return t}static _$Eu(e,t){let n=t.attribute;return n===!1?void 0:typeof n=="string"?n:typeof e=="string"?e.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){this._$ES=new Promise(e=>this.enableUpdating=e),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach(e=>e(this))}addController(e){(this._$EO??=new Set).add(e),this.renderRoot!==void 0&&this.isConnected&&e.hostConnected?.()}removeController(e){this._$EO?.delete(e)}_$E_(){let e=new Map,t=this.constructor.elementProperties;for(let n of t.keys())this.hasOwnProperty(n)&&(e.set(n,this[n]),delete this[n]);e.size>0&&(this._$Ep=e)}createRenderRoot(){let e=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return et(e,this.constructor.elementStyles),e}connectedCallback(){this.renderRoot??=this.createRenderRoot(),this.enableUpdating(!0),this._$EO?.forEach(e=>e.hostConnected?.())}enableUpdating(e){}disconnectedCallback(){this._$EO?.forEach(e=>e.hostDisconnected?.())}attributeChangedCallback(e,t,n){this._$AK(e,n)}_$ET(e,t){let n=this.constructor.elementProperties.get(e),i=this.constructor._$Eu(e,n);if(i!==void 0&&n.reflect===!0){let s=(n.converter?.toAttribute!==void 0?n.converter:fe).toAttribute(t,n.type);this._$Em=e,s==null?this.removeAttribute(i):this.setAttribute(i,s),this._$Em=null}}_$AK(e,t){let n=this.constructor,i=n._$Eh.get(e);if(i!==void 0&&this._$Em!==i){let s=n.getPropertyOptions(i),a=typeof s.converter=="function"?{fromAttribute:s.converter}:s.converter?.fromAttribute!==void 0?s.converter:fe;this._$Em=i;let o=a.fromAttribute(t,s.type);this[i]=o??this._$Ej?.get(i)??o,this._$Em=null}}requestUpdate(e,t,n,i=!1,s){if(e!==void 0){let a=this.constructor;if(i===!1&&(s=this[e]),n??=a.getPropertyOptions(e),!((n.hasChanged??it)(s,t)||n.useDefault&&n.reflect&&s===this._$Ej?.get(e)&&!this.hasAttribute(a._$Eu(e,n))))return;this.C(e,t,n)}this.isUpdatePending===!1&&(this._$ES=this._$EP())}C(e,t,{useDefault:n,reflect:i,wrapped:s},a){n&&!(this._$Ej??=new Map).has(e)&&(this._$Ej.set(e,a??t??this[e]),s!==!0||a!==void 0)||(this._$AL.has(e)||(this.hasUpdated||n||(t=void 0),this._$AL.set(e,t)),i===!0&&this._$Em!==e&&(this._$Eq??=new Set).add(e))}async _$EP(){this.isUpdatePending=!0;try{await this._$ES}catch(t){Promise.reject(t)}let e=this.scheduleUpdate();return e!=null&&await e,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??=this.createRenderRoot(),this._$Ep){for(let[i,s]of this._$Ep)this[i]=s;this._$Ep=void 0}let n=this.constructor.elementProperties;if(n.size>0)for(let[i,s]of n){let{wrapped:a}=s,o=this[i];a!==!0||this._$AL.has(i)||o===void 0||this.C(i,void 0,s,o)}}let e=!1,t=this._$AL;try{e=this.shouldUpdate(t),e?(this.willUpdate(t),this._$EO?.forEach(n=>n.hostUpdate?.()),this.update(t)):this._$EM()}catch(n){throw e=!1,this._$EM(),n}e&&this._$AE(t)}willUpdate(e){}_$AE(e){this._$EO?.forEach(t=>t.hostUpdated?.()),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(e)),this.updated(e)}_$EM(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(e){return!0}update(e){this._$Eq&&=this._$Eq.forEach(t=>this._$ET(t,this[t])),this._$EM()}updated(e){}firstUpdated(e){}};P.elementStyles=[],P.shadowRootOptions={mode:"open"},P[K("elementProperties")]=new Map,P[K("finalized")]=new Map,Ft?.({ReactiveElement:P}),(oe.reactiveElementVersions??=[]).push("2.1.2");var Ae=globalThis,st=r=>r,le=Ae.trustedTypes,rt=le?le.createPolicy("lit-html",{createHTML:r=>r}):void 0,dt="$lit$",T=`lit$${Math.random().toFixed(9).slice(2)}$`,pt="?"+T,Ht=`<${pt}>`,O=document,Y=()=>O.createComment(""),q=r=>r===null||typeof r!="object"&&typeof r!="function",Ee=Array.isArray,Ut=r=>Ee(r)||typeof r?.[Symbol.iterator]=="function",ve=`[ 	
\f\r]`,j=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,at=/-->/g,ot=/>/g,z=RegExp(`>|${ve}(?:([^\\s"'>=/]+)(${ve}*=${ve}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`,"g"),lt=/'/g,ct=/"/g,ht=/^(?:script|style|textarea|title)$/i,_e=r=>(e,...t)=>({_$litType$:r,strings:e,values:t}),h=_e(1),J=_e(2),dn=_e(3),F=Symbol.for("lit-noChange"),y=Symbol.for("lit-nothing"),ut=new WeakMap,I=O.createTreeWalker(O,129);function mt(r,e){if(!Ee(r)||!r.hasOwnProperty("raw"))throw Error("invalid template strings array");return rt!==void 0?rt.createHTML(e):e}var Zt=(r,e)=>{let t=r.length-1,n=[],i,s=e===2?"<svg>":e===3?"<math>":"",a=j;for(let o=0;o<t;o++){let l=r[o],m,b,u=-1,d=0;for(;d<l.length&&(a.lastIndex=d,b=a.exec(l),b!==null);)d=a.lastIndex,a===j?b[1]==="!--"?a=at:b[1]!==void 0?a=ot:b[2]!==void 0?(ht.test(b[2])&&(i=RegExp("</"+b[2],"g")),a=z):b[3]!==void 0&&(a=z):a===z?b[0]===">"?(a=i??j,u=-1):b[1]===void 0?u=-2:(u=a.lastIndex-b[2].length,m=b[1],a=b[3]===void 0?z:b[3]==='"'?ct:lt):a===ct||a===lt?a=z:a===at||a===ot?a=j:(a=z,i=void 0);let c=a===z&&r[o+1].startsWith("/>")?" ":"";s+=a===j?l+Ht:u>=0?(n.push(m),l.slice(0,u)+dt+l.slice(u)+T+c):l+T+(u===-2?o:c)}return[mt(r,s+(r[t]||"<?>")+(e===2?"</svg>":e===3?"</math>":"")),n]},G=class r{constructor({strings:e,_$litType$:t},n){let i;this.parts=[];let s=0,a=0,o=e.length-1,l=this.parts,[m,b]=Zt(e,t);if(this.el=r.createElement(m,n),I.currentNode=this.el.content,t===2||t===3){let u=this.el.content.firstChild;u.replaceWith(...u.childNodes)}for(;(i=I.nextNode())!==null&&l.length<o;){if(i.nodeType===1){if(i.hasAttributes())for(let u of i.getAttributeNames())if(u.endsWith(dt)){let d=b[a++],c=i.getAttribute(u).split(T),p=/([.?@])?(.*)/.exec(d);l.push({type:1,index:s,name:p[2],strings:c,ctor:p[1]==="."?ye:p[1]==="?"?$e:p[1]==="@"?xe:U}),i.removeAttribute(u)}else u.startsWith(T)&&(l.push({type:6,index:s}),i.removeAttribute(u));if(ht.test(i.tagName)){let u=i.textContent.split(T),d=u.length-1;if(d>0){i.textContent=le?le.emptyScript:"";for(let c=0;c<d;c++)i.append(u[c],Y()),I.nextNode(),l.push({type:2,index:++s});i.append(u[d],Y())}}}else if(i.nodeType===8)if(i.data===pt)l.push({type:2,index:s});else{let u=-1;for(;(u=i.data.indexOf(T,u+1))!==-1;)l.push({type:7,index:s}),u+=T.length-1}s++}}static createElement(e,t){let n=O.createElement("template");return n.innerHTML=e,n}};function H(r,e,t=r,n){if(e===F)return e;let i=n!==void 0?t._$Co?.[n]:t._$Cl,s=q(e)?void 0:e._$litDirective$;return i?.constructor!==s&&(i?._$AO?.(!1),s===void 0?i=void 0:(i=new s(r),i._$AT(r,t,n)),n!==void 0?(t._$Co??=[])[n]=i:t._$Cl=i),i!==void 0&&(e=H(r,i._$AS(r,e.values),i,n)),e}var ge=class{constructor(e,t){this._$AV=[],this._$AN=void 0,this._$AD=e,this._$AM=t}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(e){let{el:{content:t},parts:n}=this._$AD,i=(e?.creationScope??O).importNode(t,!0);I.currentNode=i;let s=I.nextNode(),a=0,o=0,l=n[0];for(;l!==void 0;){if(a===l.index){let m;l.type===2?m=new X(s,s.nextSibling,this,e):l.type===1?m=new l.ctor(s,l.name,l.strings,this,e):l.type===6&&(m=new we(s,this,e)),this._$AV.push(m),l=n[++o]}a!==l?.index&&(s=I.nextNode(),a++)}return I.currentNode=O,i}p(e){let t=0;for(let n of this._$AV)n!==void 0&&(n.strings!==void 0?(n._$AI(e,n,t),t+=n.strings.length-2):n._$AI(e[t])),t++}},X=class r{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(e,t,n,i){this.type=2,this._$AH=y,this._$AN=void 0,this._$AA=e,this._$AB=t,this._$AM=n,this.options=i,this._$Cv=i?.isConnected??!0}get parentNode(){let e=this._$AA.parentNode,t=this._$AM;return t!==void 0&&e?.nodeType===11&&(e=t.parentNode),e}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(e,t=this){e=H(this,e,t),q(e)?e===y||e==null||e===""?(this._$AH!==y&&this._$AR(),this._$AH=y):e!==this._$AH&&e!==F&&this._(e):e._$litType$!==void 0?this.$(e):e.nodeType!==void 0?this.T(e):Ut(e)?this.k(e):this._(e)}O(e){return this._$AA.parentNode.insertBefore(e,this._$AB)}T(e){this._$AH!==e&&(this._$AR(),this._$AH=this.O(e))}_(e){this._$AH!==y&&q(this._$AH)?this._$AA.nextSibling.data=e:this.T(O.createTextNode(e)),this._$AH=e}$(e){let{values:t,_$litType$:n}=e,i=typeof n=="number"?this._$AC(e):(n.el===void 0&&(n.el=G.createElement(mt(n.h,n.h[0]),this.options)),n);if(this._$AH?._$AD===i)this._$AH.p(t);else{let s=new ge(i,this),a=s.u(this.options);s.p(t),this.T(a),this._$AH=s}}_$AC(e){let t=ut.get(e.strings);return t===void 0&&ut.set(e.strings,t=new G(e)),t}k(e){Ee(this._$AH)||(this._$AH=[],this._$AR());let t=this._$AH,n,i=0;for(let s of e)i===t.length?t.push(n=new r(this.O(Y()),this.O(Y()),this,this.options)):n=t[i],n._$AI(s),i++;i<t.length&&(this._$AR(n&&n._$AB.nextSibling,i),t.length=i)}_$AR(e=this._$AA.nextSibling,t){for(this._$AP?.(!1,!0,t);e!==this._$AB;){let n=st(e).nextSibling;st(e).remove(),e=n}}setConnected(e){this._$AM===void 0&&(this._$Cv=e,this._$AP?.(e))}},U=class{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(e,t,n,i,s){this.type=1,this._$AH=y,this._$AN=void 0,this.element=e,this.name=t,this._$AM=i,this.options=s,n.length>2||n[0]!==""||n[1]!==""?(this._$AH=Array(n.length-1).fill(new String),this.strings=n):this._$AH=y}_$AI(e,t=this,n,i){let s=this.strings,a=!1;if(s===void 0)e=H(this,e,t,0),a=!q(e)||e!==this._$AH&&e!==F,a&&(this._$AH=e);else{let o=e,l,m;for(e=s[0],l=0;l<s.length-1;l++)m=H(this,o[n+l],t,l),m===F&&(m=this._$AH[l]),a||=!q(m)||m!==this._$AH[l],m===y?e=y:e!==y&&(e+=(m??"")+s[l+1]),this._$AH[l]=m}a&&!i&&this.j(e)}j(e){e===y?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,e??"")}},ye=class extends U{constructor(){super(...arguments),this.type=3}j(e){this.element[this.name]=e===y?void 0:e}},$e=class extends U{constructor(){super(...arguments),this.type=4}j(e){this.element.toggleAttribute(this.name,!!e&&e!==y)}},xe=class extends U{constructor(e,t,n,i,s){super(e,t,n,i,s),this.type=5}_$AI(e,t=this){if((e=H(this,e,t,0)??y)===F)return;let n=this._$AH,i=e===y&&n!==y||e.capture!==n.capture||e.once!==n.once||e.passive!==n.passive,s=e!==y&&(n===y||i);i&&this.element.removeEventListener(this.name,this,n),s&&this.element.addEventListener(this.name,this,e),this._$AH=e}handleEvent(e){typeof this._$AH=="function"?this._$AH.call(this.options?.host??this.element,e):this._$AH.handleEvent(e)}},we=class{constructor(e,t,n){this.element=e,this.type=6,this._$AN=void 0,this._$AM=t,this.options=n}get _$AU(){return this._$AM._$AU}_$AI(e){H(this,e)}};var Wt=Ae.litHtmlPolyfillSupport;Wt?.(G,X),(Ae.litHtmlVersions??=[]).push("3.3.3");var bt=(r,e,t)=>{let n=t?.renderBefore??e,i=n._$litPart$;if(i===void 0){let s=t?.renderBefore??null;n._$litPart$=i=new X(e.insertBefore(Y(),s),s,void 0,t??{})}return i._$AI(r),i};var Se=globalThis,R=class extends P{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){let e=super.createRenderRoot();return this.renderOptions.renderBefore??=e.firstChild,e}update(e){let t=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(e),this._$Do=bt(t,this.renderRoot,this.renderOptions)}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0)}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1)}render(){return F}};R._$litElement$=!0,R.finalized=!0,Se.litElementHydrateSupport?.({LitElement:R});var Kt=Se.litElementPolyfillSupport;Kt?.({LitElement:R});(Se.litElementVersions??=[]).push("4.2.2");var jt=["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"];function B(r,e=60){let t=Number(r);return Number.isFinite(t)?Math.max(0,Math.min(127,Math.round(t))):e}function A(r,e=100){let t=Number(r);return Number.isFinite(t)?Math.max(1,Math.min(127,Math.round(t))):e}function E(r){let e=B(r),t=Math.floor(e/12)-1;return jt[e%12]+t}function ft(r){let e=r.trim(),t=Number.parseInt(e,10);if(String(t)===e&&t>=0&&t<=127)return t;let n=e.match(/^([A-Ga-g])([#b]?)\s*(-?\d+)$/);if(!n)return null;let s={c:0,d:2,e:4,f:5,g:7,a:9,b:11}[n[1].toLowerCase()];if(s===void 0)return null;let a=s;n[2]==="#"&&(a+=1),n[2]==="b"&&(a-=1);let l=(Number.parseInt(n[3],10)+1)*12+a;return l>=0&&l<=127?l:null}function Ce(r,e,t=48){let n=Math.max(1,Math.min(128,Math.round(e||1))),i=r.slice(0,n).map(a=>B(a)),s=i.length>0?i[i.length-1]+1:t;for(;i.length<n;)i.push(B(s)),s+=1;return i}function ce(r,e,t=100){let n=Math.max(1,Math.min(128,Math.round(e||1))),i=r.slice(0,n).map(s=>A(s,t));for(;i.length<n;)i.push(A(t));return i}function Yt(r){return typeof r=="string"&&/^[A-Za-z_][A-Za-z0-9_]*$/.test(r)}function qt(r,e,t){let n={type:"note",note:B(e),velocity:A(t)};if(!r||typeof r!="object")return n;let i=r,s=typeof i.label=="string"?i.label:void 0;if(i.type==="trait"&&Yt(i.trait)){let l=i.value;if(typeof l=="number"||typeof l=="boolean"||typeof l=="string")return{type:"trait",trait:i.trait,value:l,label:s}}if(i.type==="event")return{type:"event",label:s,value:i.value};let a={type:"note",note:B(i.note,e),velocity:A(i.velocity,t),label:s},o=Number(i.slice);return Number.isInteger(o)&&o>=0&&(a.slice=o),a}function Ne(r,e,t,n){let i=Array.isArray(r)?r:[],s=[],a=Math.max(1,Math.round(n||e.length||1));for(let o=0;o<a;o++)s.push(qt(i[o],e[o]??e[e.length-1]??60,t[o]??t[t.length-1]??100));return s}function vt(r){return r.label?r.label:r.type==="note"?E(r.note):r.type==="trait"?r.trait:"event"}function ue(r){return r?globalThis.__nbplay?.[r]:void 0}function S(r,e){let t=Number(r);return Number.isFinite(t)?Math.max(0,Math.min(127,Math.round(t))):e}function gt(r,e,t){return e>=r.note_low&&e<=r.note_high&&t>=r.velocity_low&&t<=r.velocity_high}function yt(r,e=2048){if(r.length<=e)return r.slice();let t=new Float32Array(e),n=r.length/e;for(let i=0;i<e;i++)t[i]=r[Math.floor(i*n)];return t}function de(r){let e=new ArrayBuffer(r.length*4),t=new DataView(e);for(let n=0;n<r.length;n++)t.setFloat32(n*4,r[n],!0);return t}function Gt(r){let e=new Float32Array(r.length),t=Math.max(1,r.numberOfChannels);for(let n=0;n<t;n++){let i=r.getChannelData(n);for(let s=0;s<e.length;s++)e[s]+=i[s]/t}return e}async function Q(r){let e=W();if(!e)return null;try{let t=await e.decodeAudioData(r);return{samples:Gt(t),sampleRate:t.sampleRate}}finally{e.state!=="closed"&&e.close()}}function $t(r=8){let e=Math.max(1,Math.round(r||8)),t=null,n=null,i=!0,s=[],a=null,o=null,l=44100,m=[];function b(){if(!t||!o||o.length===0)return!1;if(a)return!0;a=t.createBuffer(1,o.length,l);let c=a.getChannelData(0);for(let p=0;p<o.length;p++)c[p]=o[p];return!0}function u(c){let p=s.indexOf(c);p>=0&&s.splice(p,1);try{c.gainNode.disconnect()}catch{}}function d(c){return!t||c.samples.length===0?null:(c.buffer||(c.buffer=t.createBuffer(1,c.samples.length,c.sample_rate),c.buffer.getChannelData(0).set(c.samples)),c.buffer)}return{setMaxVoices(c){e=Math.max(1,Math.round(Number(c)||8))},setSession(c,p){if(c&&p>=0){let f=ue(c);if(f?.audioCtx&&f.channels?.[p]){t!==f.audioCtx&&(i&&t&&(this.stopAll(),t.state!=="closed"&&t.close()),a=null,m.forEach(C=>C.buffer=null)),t=f.audioCtx,n=f.channels[p].gain,i=!1;return}}},setWaveformData(c,p){if(!(!c||c.length===0)){o=new Float32Array(c.length);for(let f=0;f<c.length;f++)o[f]=c[f];l=p,a=null,t||(t=W({sampleRate:p}),t&&(i=!0))}},setZones(c){m=c.map(p=>({...p,buffer:null})),!t&&m.length>0&&(t=W(),t&&(i=!0))},zoneFor(c,p){return m.find(f=>gt(f,c,p))},noteOn(c,p,f,C=127,$,L,te){let ne=m.find(w=>gt(w,c,A(C,127))),ie=ne?d(ne):null;if(!t||!ie&&!b())return;t.state==="suspended"&&t.resume();let Pt=c-(ne?ne.root_note:p),Mt=Math.pow(2,Pt/12),N=t.createBufferSource();N.buffer=ie||a,N.playbackRate.value=Mt;let Ue=!ie&&$!==void 0&&$.end>$.start&&$.start>=0&&$.end<=o.length;N.loop=!Ue&&!ie;let V=t.createGain();V.connect(n||t.destination),N.connect(V);let k=L??t.currentTime,Ze=Math.max(f.attack,.005),pe=A(C,127)/127;if(V.gain.setValueAtTime(0,k),V.gain.linearRampToValueAtTime(pe,k+Ze),V.gain.linearRampToValueAtTime(f.sustain*pe,k+Ze+f.decay),Ue&&$){let w=$.start/l,D=($.end-$.start)/l;N.start(k,w,D)}else N.start(k);let We=null;if(te!==void 0){let w=k+Math.max(.001,te);We=w;let D=V.gain;typeof D.cancelAndHoldAtTime=="function"?D.cancelAndHoldAtTime(w):(D.cancelScheduledValues(w),D.setValueAtTime(f.sustain*pe,w)),D.linearRampToValueAtTime(0,w+f.release),N.stop(w+f.release+.01)}let he={gainNode:V,sourceNode:N,noteNum:c,startTime:k,releaseTime:We};N.onended=()=>u(he),s.push(he);let Ke=s.filter(w=>w.releaseTime===null);if(Ke.length>e){let w=Ke[0];w.releaseTime=k;try{w.sourceNode.stop(k)}catch{}}return he},noteOff(c,p){if(!t)return;let f=t.currentTime;s.filter($=>$.noteNum===c&&$.releaseTime===null).forEach($=>{$.releaseTime=f;let L=$.gainNode.gain.value;$.gainNode.gain.setValueAtTime(L,f),$.gainNode.gain.linearRampToValueAtTime(0,f+p.release),$.sourceNode.stop(f+p.release),setTimeout(()=>u($),p.release*1e3+10)})},cancelVoice(c){try{c.sourceNode.stop(0)}catch{}u(c)},getActiveVoiceCount(){return s.filter(c=>c.releaseTime===null).length},stopAll(){if(!t)return;let c=t.currentTime;[...s].forEach(p=>{try{p.sourceNode.stop(c)}catch{}u(p)}),s.length=0},destroy(){this.stopAll(),i&&t&&t.state!=="closed"&&t.close(),t=null,n=null,i=!0}}}var v=class extends R{constructor(){super(),this.theme=""}createRenderRoot(){return this}emit(e,t){this.emitDetail(e,{value:t})}emitDetail(e,t){this.dispatchEvent(new CustomEvent(e,{detail:t,bubbles:!0,composed:!0}))}};v.createProperty("theme",{type:String,attribute:"data-nbplay-theme",reflect:!0,converter:{fromAttribute:r=>r??"",toAttribute:r=>r||null}});function g(r,e){customElements.get(r)||customElements.define(r,e)}function x(r,e,t){return Math.min(t,Math.max(e,r))}function Z(r,e){if(!(e>0))return r;let t=Math.max(0,Math.ceil(-Math.log10(e)));return Number((Math.round(r/e)*e).toFixed(t))}var xt=.3,ke=class extends v{static properties={attack:{type:Number},decay:{type:Number},sustain:{type:Number},release:{type:Number}};observer;constructor(){super(),this.attack=.005,this.decay=.1,this.sustain=.8,this.release=.1}render(){return h`<canvas class="nbplay-envelope-canvas"></canvas>`}firstUpdated(){this.observer=new ResizeObserver(()=>this.draw()),this.observer.observe(this)}disconnectedCallback(){super.disconnectedCallback(),this.observer?.disconnect()}updated(){this.draw()}draw(){let e=this.querySelector("canvas");if(!e)return;let t=this.clientWidth,n=this.clientHeight;if(t===0||n===0)return;let i=window.devicePixelRatio||1;e.width=Math.round(t*i),e.height=Math.round(n*i);let s=e.getContext("2d");if(!s)return;s.setTransform(i,0,0,i,0,0);let a=_(this,"--nbplay-chart-bg","#121214"),o=_(this,"--nbplay-chart-line","#f28c38"),l=_(this,"--nbplay-fg-muted","#a8a59c");s.fillStyle=a,s.fillRect(0,0,t,n);let m=this.attack+this.decay+xt+this.release||1,b=t/m,u=8,d=n-14,c=L=>d-L*(d-u),p=this.attack*b,f=p+this.decay*b,C=f+xt*b;s.beginPath(),s.moveTo(0,d),s.lineTo(p,c(1)),s.lineTo(f,c(this.sustain)),s.lineTo(C,c(this.sustain)),s.lineTo(t,d),s.strokeStyle=o,s.lineWidth=2,s.lineJoin="round",s.stroke(),s.lineTo(0,d),s.closePath(),s.fillStyle=o,s.globalAlpha=.15,s.fill(),s.globalAlpha=1,s.fillStyle=l,s.font="10px "+_(this,"--nbplay-font-mono","monospace"),s.textAlign="center",s.textBaseline="bottom";let $=[["A",p/2],["D",(p+f)/2],["S",(f+C)/2],["R",(C+t)/2]];for(let[L,te]of $)s.fillText(L,Math.min(Math.max(te,6),t-6),n-2)}};g("nbplay-envelope",ke);var Pe=class extends v{static properties={title:{type:String},badge:{type:String},status:{type:String}};actions=null;constructor(){super(),this.title="nbplay",this.badge="",this.status=""}connectedCallback(){this.actions===null&&(this.actions=Array.from(this.childNodes)),super.connectedCallback()}render(){let e=this.actions??[];return h`<h3 class="nbplay-header-title">${this.title}</h3>
      ${this.badge?h`<span class="nbplay-header-badge">${this.badge}</span>`:y}
      ${this.status?h`<span class="nbplay-header-status">${this.status}</span>`:y}
      <div class="nbplay-header-actions">${e}</div>`}};g("nbplay-header",Pe);var Me=class extends v{static properties={value:{type:Number},min:{type:Number},max:{type:Number},step:{type:Number},orientation:{type:String,reflect:!0},editable:{type:String,reflect:!0},wheelStep:{type:Number,attribute:"wheel-step"},disabled:{type:Boolean,reflect:!0},dragging:{type:Boolean,reflect:!0}};constructor(){super(),this.value=0,this.min=0,this.max=127,this.step=1,this.orientation="vertical",this.editable="",this.wheelStep=1,this.disabled=!1,this.dragging=!1}connectedCallback(){super.connectedCallback(),this.addEventListener("wheel",this.onWheel,{passive:!1}),this.addEventListener("pointerdown",this.onPointerDown),this.addEventListener("pointermove",this.onPointerMove),this.addEventListener("pointerup",this.onPointerUp),this.addEventListener("lostpointercapture",this.onPointerUp)}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener("wheel",this.onWheel),this.removeEventListener("pointerdown",this.onPointerDown),this.removeEventListener("pointermove",this.onPointerMove),this.removeEventListener("pointerup",this.onPointerUp),this.removeEventListener("lostpointercapture",this.onPointerUp)}can(e){return!this.disabled&&this.editable.split(/\s+/).includes(e)}get percent(){return this.max>this.min?x((this.value-this.min)/(this.max-this.min),0,1)*100:0}render(){return h`<div class="nbplay-bar-track">
      <div
        class="nbplay-bar-fill"
        style="--nbplay-bar-fill: ${this.percent}%"
      ></div>
    </div>`}set(e,t){let n=x(Z(e,this.step),this.min,this.max);n!==this.value&&(this.value=n,this.emit("input",n)),t&&this.emit("change",this.value)}fromPointer(e){let t=this.getBoundingClientRect(),n=this.orientation==="vertical"?1-(e.clientY-t.top)/t.height:(e.clientX-t.left)/t.width;return this.min+x(n,0,1)*(this.max-this.min)}onWheel=e=>{if(!this.can("wheel"))return;e.preventDefault();let t=e.deltaY!==0?e.deltaY:e.deltaX;t!==0&&this.set(this.value+(t<0?this.wheelStep:-this.wheelStep),!0)};onPointerDown=e=>{!this.can("drag")||e.button!==0||(e.preventDefault(),this.setPointerCapture(e.pointerId),this.dragging=!0,this.set(this.fromPointer(e),!1))};onPointerMove=e=>{this.dragging&&this.set(this.fromPointer(e),!1)};onPointerUp=()=>{this.dragging&&(this.dragging=!1,this.emit("change",this.value))}};g("nbplay-bar",Me);var Xt=5,Jt=300,Te=class extends v{static properties={rows:{type:Number},cols:{type:Number},pads:{attribute:!1},active:{attribute:!1},velocitySensitive:{type:Boolean,attribute:"velocity-sensitive"},hold:{type:Boolean},editable:{type:Boolean},disabled:{type:Boolean,reflect:!0}};held=new Set;pendingTap;press;constructor(){super(),this.rows=4,this.cols=4,this.pads=[],this.active=[],this.velocitySensitive=!0,this.hold=!1,this.editable=!0,this.disabled=!1}pad(e){return this.pads[e]??{note:60+e,velocity:100}}render(){let e=this.rows*this.cols;return h`<div
      class="nbplay-pad-grid-cells"
      style="grid-template-columns: repeat(${this.cols}, 1fr); grid-template-rows: repeat(${this.rows}, 1fr)"
    >
      ${Array.from({length:e},(t,n)=>this.renderCell(n))}
    </div>`}renderCell(e){let t=this.pad(e),n=this.held.has(e)||this.active.includes(e),i=`Pad ${e+1}: ${t.label??E(t.note)}  vel=${t.velocity}`;return h`<div
      class="nbplay-pad-cell ${n?"active":""}"
      data-index=${e}
      title=${i}
      @pointerdown=${s=>this.onPointerDown(s,e)}
      @pointermove=${this.onPointerMove}
      @pointerup=${this.onPointerUp}
      @pointercancel=${this.onPointerCancel}
      @lostpointercapture=${this.onPointerCancel}
      @wheel=${s=>this.onWheel(s,e)}
    >
      <nbplay-bar
        class="nbplay-pad-vel"
        .value=${t.velocity}
        .max=${127}
        .min=${0}
      ></nbplay-bar>
      ${t.label!==void 0?h`<span class="nbplay-pad-label">${t.label}</span>`:h`<nbplay-value
              class="nbplay-pad-label"
              kind="note"
              .value=${t.note}
              .min=${0}
              .max=${127}
              .editable=${this.editable}
              @dblclick=${()=>clearTimeout(this.pendingTap)}
              @change=${s=>this.onLabelChange(s,e)}
            ></nbplay-value>`}
    </div>`}tapVelocity(e,t,n){let i=this.pad(n).velocity;if(!this.velocitySensitive)return i;let s=t.getBoundingClientRect(),a=x((e.clientY-s.top)/s.height,0,1);return A(Math.round(20+a*(i-20)))}noteOn(e,t){this.held.add(e),this.requestUpdate(),this.emitDetail("nbplay-note-on",{index:e,note:this.pad(e).note,velocity:t})}noteOff(e){this.held.delete(e)&&(this.requestUpdate(),this.emitDetail("nbplay-note-off",{index:e,note:this.pad(e).note}))}onPointerDown(e,t){if(this.disabled||e.button!==0)return;let n=e.currentTarget,i=e.target.closest("nbplay-value")!==null;if(!i){e.preventDefault();try{n.setPointerCapture(e.pointerId)}catch{}}this.press={index:t,pointerId:e.pointerId,startY:e.clientY,onLabel:i,dragging:!1,cell:n},this.hold&&!i&&this.noteOn(t,this.tapVelocity(e,n,t))}onPointerMove=e=>{let t=this.press;if(!t||t.pointerId!==e.pointerId||!this.editable||this.hold||!t.dragging&&Math.abs(e.clientY-t.startY)<Xt)return;t.dragging=!0;let n=t.cell.getBoundingClientRect(),i=A(Math.round((1-(e.clientY-n.top)/n.height)*127));this.setPad(t.index,"velocity",i,"input")};onPointerUp=e=>{let t=this.press;if(!t||t.pointerId!==e.pointerId)return;if(this.press=void 0,this.hold){this.noteOff(t.index);return}if(t.dragging){this.emitDetail("change",{index:t.index,field:"velocity",value:this.pad(t.index).velocity});return}let n=this.tapVelocity(e,t.cell,t.index),i=()=>{this.noteOn(t.index,n),requestAnimationFrame(()=>this.noteOff(t.index))};if(!t.onLabel){i();return}let s=t.cell.querySelector("nbplay-value");clearTimeout(this.pendingTap),this.pendingTap=setTimeout(()=>{this.pendingTap=void 0,s?.editing||i()},Jt)};onPointerCancel=e=>{let t=this.press;!t||t.pointerId!==e.pointerId||(this.press=void 0,this.hold?this.noteOff(t.index):t.dragging&&this.emitDetail("change",{index:t.index,field:"velocity",value:this.pad(t.index).velocity}))};onWheel(e,t){if(!this.editable||this.disabled)return;e.preventDefault();let n=e.deltaY!==0?e.deltaY:e.deltaX;if(n===0)return;let i=this.pad(t);e.shiftKey?this.setPad(t,"velocity",A(i.velocity+(n<0?5:-5)),"change"):this.setPad(t,"note",B(i.note+(n<0?1:-1)),"change")}onLabelChange(e,t){e.stopPropagation();let n=e.detail?.value;this.setPad(t,"note",B(n),"change")}setPad(e,t,n,i){let s=this.pad(e);if(s[t]===n)return;let a=this.pads.slice();a[e]={...s,[t]:n},this.pads=a,this.emitDetail(i,{index:e,field:t,value:n})}};g("nbplay-pad-grid",Te);var wt=270,ee=-135,At=150;function Re(r,e){let t=(r-90)*Math.PI/180;return[50+e*Math.cos(t),50+e*Math.sin(t)]}function Et(r,e,t){let[n,i]=Re(r,t),[s,a]=Re(e,t),o=e-r>180?1:0;return`M ${n} ${i} A ${t} ${t} 0 ${o} 1 ${s} ${a}`}var Be=class extends v{static properties={value:{type:Number},min:{type:Number},max:{type:Number},step:{type:Number},defaultValue:{type:Number,attribute:"default-value"},disabled:{type:Boolean,reflect:!0},dragging:{type:Boolean,reflect:!0}};startY=0;startValue=0;constructor(){super(),this.value=0,this.min=0,this.max=1,this.step=.01,this.defaultValue=null,this.disabled=!1,this.dragging=!1}connectedCallback(){super.connectedCallback(),this.hasAttribute("tabindex")||(this.tabIndex=0),this.setAttribute("role","slider"),this.addEventListener("pointerdown",this.onPointerDown),this.addEventListener("pointermove",this.onPointerMove),this.addEventListener("pointerup",this.onPointerUp),this.addEventListener("lostpointercapture",this.onPointerUp),this.addEventListener("wheel",this.onWheel,{passive:!1}),this.addEventListener("keydown",this.onKeydown),this.addEventListener("dblclick",this.onDblclick)}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener("pointerdown",this.onPointerDown),this.removeEventListener("pointermove",this.onPointerMove),this.removeEventListener("pointerup",this.onPointerUp),this.removeEventListener("lostpointercapture",this.onPointerUp),this.removeEventListener("wheel",this.onWheel),this.removeEventListener("keydown",this.onKeydown),this.removeEventListener("dblclick",this.onDblclick)}updated(){this.setAttribute("aria-valuemin",String(this.min)),this.setAttribute("aria-valuemax",String(this.max)),this.setAttribute("aria-valuenow",String(this.value)),this.setAttribute("aria-disabled",String(this.disabled))}fraction(){return this.max>this.min?x((this.value-this.min)/(this.max-this.min),0,1):0}render(){let e=ee+this.fraction()*wt,[t,n]=Re(e,30);return h`<svg
      class="nbplay-dial-svg"
      viewBox="0 0 100 100"
      aria-hidden="true"
    >
      ${J`<path class="nbplay-dial-track" d=${Et(ee,ee+wt,40)} />`}
      ${J`<path class="nbplay-dial-arc" d=${Et(ee,Math.max(e,ee+.01),40)} />`}
      ${J`<circle class="nbplay-dial-cap" cx="50" cy="50" r="30" />`}
      ${J`<line class="nbplay-dial-indicator" x1="50" y1="50" x2=${t} y2=${n} />`}
    </svg>`}set(e,t){let n=x(Z(e,this.step),this.min,this.max);n!==this.value&&(this.value=n,this.emit("input",n)),t&&this.emit("change",this.value)}reset(){this.disabled||this.defaultValue===null||(this.dragging=!1,this.set(this.defaultValue,!0))}onDblclick=()=>this.reset();onPointerDown=e=>{this.disabled||e.button!==0||(e.preventDefault(),this.focus(),this.setPointerCapture(e.pointerId),this.dragging=!0,this.startY=e.clientY,this.startValue=this.value)};onPointerMove=e=>{if(!this.dragging)return;let t=e.shiftKey?At*4:At,n=(this.startY-e.clientY)/t*(this.max-this.min);this.set(this.startValue+n,!1)};onPointerUp=()=>{this.dragging&&(this.dragging=!1,this.emit("change",this.value))};onWheel=e=>{if(this.disabled)return;e.preventDefault();let t=e.deltaY!==0?e.deltaY:e.deltaX;t!==0&&this.set(this.value+(t<0?this.step:-this.step),!0)};onKeydown=e=>{if(this.disabled)return;let t=this.step*10,n={ArrowUp:this.step,ArrowRight:this.step,ArrowDown:-this.step,ArrowLeft:-this.step,PageUp:t,PageDown:-t},i;e.key in n?i=this.value+n[e.key]:e.key==="Home"?i=this.min:e.key==="End"&&(i=this.max),i!==void 0&&(e.preventDefault(),this.set(i,!0))}};g("nbplay-dial",Be);var Le=class extends v{static properties={value:{type:Number},min:{type:Number},max:{type:Number},step:{type:Number},defaultValue:{type:Number,attribute:"default-value"},orientation:{type:String,reflect:!0},scale:{type:String},disabled:{type:Boolean,reflect:!0},dragging:{type:Boolean,reflect:!0}};internal=!1;constructor(){super(),this.value=0,this.min=0,this.max=1,this.step=.01,this.defaultValue=null,this.orientation="horizontal",this.scale="linear",this.disabled=!1,this.dragging=!1}willUpdate(e){e.has("value")&&this.dragging&&!this.internal&&(this.value=e.get("value"))}toPos(e){if(this.scale!=="log")return e;let t=Math.log(this.min),n=Math.log(this.max);return(Math.log(Math.max(e,this.min))-t)/(n-t)}fromPos(e){if(this.scale!=="log")return e;let t=Math.log(this.min),n=Math.log(this.max);return Math.exp(t+e*(n-t))}render(){let e=this.scale==="log";return h`<input
      type="range"
      class="nbplay-slider-input"
      min=${e?0:this.min}
      max=${e?1:this.max}
      step=${e?.001:this.step}
      .value=${String(this.toPos(this.value))}
      ?disabled=${this.disabled}
      aria-valuemin=${this.min}
      aria-valuemax=${this.max}
      aria-valuenow=${this.value}
      @input=${this.onInput}
      @change=${this.onChange}
      @pointerdown=${this.startDrag}
      @pointerup=${this.endDrag}
      @lostpointercapture=${this.endDrag}
      @dblclick=${this.reset}
    />`}readValue(e){let t=parseFloat(e.target.value);return x(Z(this.fromPos(t),this.step),this.min,this.max)}onInput(e){e.stopPropagation(),this.internal=!0,this.value=this.readValue(e),this.internal=!1,this.emit("input",this.value)}onChange(e){e.stopPropagation(),this.endDrag(),this.emit("change",this.value)}reset(){if(this.disabled||this.defaultValue===null)return;this.endDrag();let e=x(this.defaultValue,this.min,this.max);e!==this.value&&(this.value=e,this.emit("input",e)),this.emit("change",this.value)}startDrag(){this.disabled||(this.dragging=!0)}endDrag(){this.dragging=!1}};g("nbplay-slider",Le);function _t(r,e,t=2,n=""){switch(e){case"int":return`${Math.round(r)}${n}`;case"db":return me(r);case"pan":return Ye(r);case"hz":return r>=1e3?(r/1e3).toFixed(2)+" kHz":r.toFixed(1)+" Hz";case"bpm":return`${Math.round(r)} BPM`;case"seconds":return r<.01?(r*1e3).toFixed(1)+" ms":r<1?(r*1e3).toFixed(0)+" ms":r.toFixed(2)+" s";case"percent":return(r*100).toFixed(0)+"%";case"note":return E(r);default:return`${r.toFixed(t)}${n}`}}function St(r,e,t=2){switch(e){case"int":case"bpm":return String(Math.round(r));case"db":return me(r).replace(" dB","");case"pan":return String(Math.round(r*100)/100);case"percent":return(r*100).toFixed(0);case"note":return E(r);case"float":return r.toFixed(t);default:return String(r)}}function Ct(r,e){let t=r.trim();if(!t)return null;switch(e){case"db":return qe(t);case"note":return ft(t);case"int":case"bpm":{let n=parseInt(t,10);return Number.isNaN(n)?null:n}case"percent":{let n=parseFloat(t);return Number.isFinite(n)?n>1?n/100:n:null}case"hz":{let n=parseFloat(t);return Number.isFinite(n)?/k/i.test(t)?n*1e3:n:null}default:{let n=parseFloat(t);return Number.isFinite(n)?n:null}}}var Nt=r=>r.stopPropagation(),Ve=class extends v{static properties={value:{type:Number},kind:{type:String},min:{type:Number},max:{type:Number},precision:{type:Number},unit:{type:String},editable:{type:Boolean},editing:{type:Boolean,reflect:!0}};constructor(){super(),this.value=0,this.kind="float",this.min=-1/0,this.max=1/0,this.precision=2,this.unit="",this.editable=!0,this.editing=!1}get text(){return _t(this.value,this.kind,this.precision,this.unit)}render(){return this.editing?h`<input
        type="text"
        class="nbplay-value-input"
        .value=${St(this.value,this.kind,this.precision)}
        @keydown=${this.onKeydown}
        @blur=${this.commit}
        @input=${Nt}
        @change=${Nt}
      />`:h`<span
      class="nbplay-value-text"
      title=${this.editable?"Double-click to edit":y}
      @dblclick=${this.startEdit}
      >${this.text}</span
    >`}startEdit(){!this.editable||this.editing||(this.editing=!0,this.updateComplete.then(()=>{let e=this.querySelector("input");e?.focus(),e?.select()}))}onKeydown(e){e.key==="Enter"?(e.preventDefault(),this.commit()):e.key==="Escape"&&(this.editing=!1)}commit(){if(!this.editing)return;let e=this.querySelector("input");if(this.editing=!1,!e)return;let t=Ct(e.value,this.kind);if(t===null)return;let n=x(t,this.min,this.max);n!==this.value&&(this.value=n,this.emit("change",n))}};g("nbplay-value",Ve);var De=class extends v{static properties={label:{type:String},value:{type:Number},min:{type:Number},max:{type:Number},step:{type:Number},defaultValue:{type:Number,attribute:"default-value"},scale:{type:String},kind:{type:String},control:{type:String,reflect:!0},precision:{type:Number},unit:{type:String},editable:{type:Boolean},disabled:{type:Boolean,reflect:!0}};constructor(){super(),this.label="",this.value=0,this.min=0,this.max=1,this.step=.01,this.defaultValue=null,this.scale="linear",this.kind="float",this.control="slider",this.precision=2,this.unit="",this.editable=!0,this.disabled=!1}render(){let e=this.control==="dial"?h`<nbplay-dial
            .value=${this.value}
            .min=${this.min}
            .max=${this.max}
            .step=${this.step}
            .defaultValue=${this.defaultValue}
            .disabled=${this.disabled}
            @input=${this.onInput}
            @change=${this.onChange}
          ></nbplay-dial>`:h`<nbplay-slider
            .value=${this.value}
            .min=${this.min}
            .max=${this.max}
            .step=${this.step}
            .defaultValue=${this.defaultValue}
            .scale=${this.scale}
            .disabled=${this.disabled}
            @input=${this.onInput}
            @change=${this.onChange}
          ></nbplay-slider>`;return h`<span class="nbplay-param-label">${this.label}</span>
      ${e}
      <nbplay-value
        .value=${this.value}
        .kind=${this.kind}
        .min=${this.min}
        .max=${this.max}
        .precision=${this.precision}
        .unit=${this.unit}
        .editable=${this.editable&&!this.disabled}
        @change=${this.onChange}
      ></nbplay-value>`}onInput(e){e.stopPropagation(),this.value=e.detail.value,this.emit("input",this.value)}onChange(e){e.stopPropagation(),this.value=e.detail.value,this.emit("change",this.value)}};g("nbplay-param",De);var ze=class extends v{static properties={data:{attribute:!1},variant:{type:String,reflect:!0},emptyText:{type:String,attribute:"empty-text"}};observer;constructor(){super(),this.data=null,this.variant="line",this.emptyText="No sample loaded"}render(){return h`<canvas class="nbplay-waveform-canvas"></canvas>`}firstUpdated(){this.observer=new ResizeObserver(()=>this.draw()),this.observer.observe(this)}disconnectedCallback(){super.disconnectedCallback(),this.observer?.disconnect()}updated(){this.draw()}draw(){let e=this.querySelector("canvas");if(!e)return;let t=this.clientWidth,n=this.clientHeight;if(t===0||n===0)return;let i=window.devicePixelRatio||1;e.width=Math.round(t*i),e.height=Math.round(n*i);let s=e.getContext("2d");if(!s)return;s.setTransform(i,0,0,i,0,0);let a=_(this,"--nbplay-chart-bg","#121214"),o=_(this,"--nbplay-chart-grid","#2f2f36"),l=_(this,"--nbplay-chart-line","#f28c38"),m=_(this,"--nbplay-fg-muted","#a8a59c");s.fillStyle=a,s.fillRect(0,0,t,n),s.strokeStyle=o,s.lineWidth=1,s.setLineDash([3,4]);for(let c of[.25,.5,.75])s.beginPath(),s.moveTo(0,c*n),s.lineTo(t,c*n),s.stroke();s.setLineDash([]);let b=M(this.data);if(!b||b.length===0){s.fillStyle=m,s.font="12px "+_(this,"--nbplay-font-mono","monospace"),s.textAlign="center",s.textBaseline="middle",s.fillText(this.emptyText,t/2,n/2);return}s.beginPath();let u=n/2,d=n*.45;for(let c=0;c<t;c++){let p=Math.floor(c/t*b.length),f=u-b[p]*d;c===0?s.moveTo(c,f):s.lineTo(c,f)}this.variant==="glow"&&(s.strokeStyle=l,s.globalAlpha=.25,s.lineWidth=6,s.stroke(),s.globalAlpha=1),s.strokeStyle=l,s.lineWidth=2,s.lineJoin="round",s.stroke()}};g("nbplay-waveform",ze);var Qt=6;function Oe(r){return`var(--nbplay-palette-${r%Qt+1})`}var Ie=class extends v{static properties={zones:{attribute:!1},selected:{type:Number},emptyText:{type:String,attribute:"empty-text"}};constructor(){super(),this.zones=[],this.selected=-1,this.emptyText="No zones"}render(){let e=Array.from({length:11},(t,n)=>n*12);return h`<div
      class="nbplay-zone-map-track ${this.zones.length?"":"empty"}"
    >
      ${e.map(t=>h`<span
            class="nbplay-zone-map-tick"
            style="left:${t/128*100}%"
            >${E(t)}</span
          >`)}
      ${this.zones.length?this.zones.map((t,n)=>this.renderSpan(t,n)):h`<span class="nbplay-zone-map-empty">${this.emptyText}</span>`}
    </div>`}renderSpan(e,t){let n=Math.min(e.low,e.high),i=Math.max(e.low,e.high),s=n/128*100,a=(i-n+1)/128*100,o=`${e.name??`Zone ${t+1}`}: ${E(n)}\u2013${E(i)}`;return h`<button
      type="button"
      class="nbplay-zone-map-span ${t===this.selected?"selected":""}"
      data-index=${t}
      title=${o}
      style="left:${s}%;width:${a}%;background:${e.color??Oe(t)}"
      @click=${()=>this.emitDetail("nbplay-zone-select",{index:t})}
    ></button>`}};g("nbplay-zone-map",Ie);var Fe=class extends v{static properties={zones:{attribute:!1},selected:{type:Number},disabled:{type:Boolean,reflect:!0}};constructor(){super(),this.zones=[],this.selected=-1,this.disabled=!1}render(){return h`${this.zones.map((e,t)=>this.renderRow(e,t))}`}renderRow(e,t){let n=s=>s.stopPropagation(),i=(s,a)=>h`<label class="nbplay-zone-list-note">
        <span>${a}</span>
        <nbplay-value
          kind="note"
          .value=${e[s]}
          .min=${0}
          .max=${127}
          .editable=${!this.disabled}
          @input=${n}
          @change=${o=>{o.stopPropagation(),this.commit(t,s,o.detail.value)}}
        ></nbplay-value>
      </label>`;return h`<div
      class="nbplay-zone-list-row ${t===this.selected?"selected":""}"
      data-index=${t}
      @click=${()=>this.emitDetail("nbplay-zone-select",{index:t})}
    >
      <span
        class="nbplay-zone-list-swatch"
        style="background:${e.color??Oe(t)}"
      ></span>
      <input
        type="text"
        class="nbplay-zone-list-name"
        title="Zone name"
        .value=${e.name}
        ?disabled=${this.disabled}
        @input=${n}
        @change=${s=>{s.stopPropagation(),this.commit(t,"name",s.target.value)}}
      />
      ${i("low","Low")} ${i("high","High")} ${i("root","Root")}
      <span class="nbplay-zone-list-info">${e.info??""}</span>
      <button
        type="button"
        class="nbplay-zone-list-remove"
        title="Remove zone"
        ?disabled=${this.disabled}
        @click=${s=>{s.stopPropagation(),this.emitDetail("nbplay-zone-remove",{index:t})}}
      >
        ×
      </button>
    </div>`}commit(e,t,n){let i=[...this.zones];i[e]={...i[e],[t]:n},this.zones=i,this.emitDetail("change",{index:e,field:t,value:n})}};g("nbplay-zone-list",Fe);var en=50;function kt(r,e){if(r===0)return"\u2014";let t=r/e;return t<1?(t*1e3).toFixed(0)+" ms":t.toFixed(2)+" s"}var He=class extends v{static properties={sampleName:{type:String,attribute:"sample-name"},sampleRate:{type:Number,attribute:"sample-rate"},sampleLength:{type:Number,attribute:"sample-length"},rootNote:{type:Number,attribute:"root-note"},waveform:{attribute:!1},sampleData:{attribute:!1},attack:{type:Number},decay:{type:Number},sustain:{type:Number},release:{type:Number},maxVoices:{type:Number,attribute:"max-voices"},padCount:{type:Number,attribute:"pad-count"},padNotes:{attribute:!1},padVelocities:{attribute:!1},padActions:{attribute:!1},sampleSlices:{attribute:!1},velocity:{type:Number},velocitySensitive:{type:Boolean,attribute:"velocity-sensitive"},zones:{attribute:!1},sessionId:{type:String,attribute:"session-id",reflect:!0},channelIndex:{type:Number,attribute:"channel-index"},activePads:{attribute:!1},lastNoteEvent:{attribute:!1},lastPadEvent:{attribute:!1},activeVoices:{type:Number,attribute:!1},zoneStatus:{type:String,attribute:!1},recording:{type:Boolean,attribute:!1}};engine=$t();held=new Set;heldNotes=new Map;voiceTimer=null;registration=null;recorder=null;recorderStream=null;recorderChunks=[];capturePad=-1;constructor(){super(),this.sampleName="",this.sampleRate=44100,this.sampleLength=0,this.rootNote=60,this.waveform=null,this.sampleData=null,this.attack=.01,this.decay=.1,this.sustain=.7,this.release=.3,this.maxVoices=8,this.padCount=8,this.padNotes=[],this.padVelocities=[],this.padActions=[],this.sampleSlices=[],this.velocity=100,this.velocitySensitive=!0,this.zones=[],this.sessionId="",this.channelIndex=-1,this.activePads=[],this.lastNoteEvent={},this.lastPadEvent={},this.activeVoices=0,this.zoneStatus="",this.recording=!1}connectedCallback(){super.connectedCallback(),this.classList.add("nbplay-sampler"),this.engine.setMaxVoices(this.maxVoices),this.engine.setSession(this.sessionId,this.channelIndex),this.loadSample(),this.engine.setZones(this.zoneList()),this.fitPads(),document.addEventListener("nbplay-bus-ready",this.onBusReady),this.register(),this.voiceTimer=setInterval(()=>{let e=this.engine.getActiveVoiceCount();e!==this.activeVoices&&(this.activeVoices=e)},en)}disconnectedCallback(){super.disconnectedCallback(),this.voiceTimer&&clearInterval(this.voiceTimer),this.voiceTimer=null,this.stopZoneRecording(),this.recorderStream?.getTracks().forEach(e=>e.stop()),document.removeEventListener("nbplay-bus-ready",this.onBusReady),this.unregister(),this.engine.destroy()}updated(e){(e.has("sessionId")||e.has("channelIndex"))&&[...e.keys()].some(t=>e.get(t)!==void 0)&&this.register(),e.has("maxVoices")&&this.engine.setMaxVoices(this.maxVoices),(e.has("sampleData")||e.has("waveform")||e.has("sampleRate"))&&[...e.keys()].some(t=>e.get(t)!==void 0)&&this.loadSample(),e.has("zones")&&e.get("zones")!==void 0&&this.engine.setZones(this.zoneList()),(e.has("padNotes")||e.has("padCount"))&&[...e.keys()].some(t=>e.get(t)!==void 0)&&this.fitPads()}set(e){this.emitDetail("nbplay-set",{values:e})}status(){this.activePads=Array.from(this.held),this.emitDetail("nbplay-status",{values:{activePads:this.activePads,lastNoteEvent:this.lastNoteEvent,lastPadEvent:this.lastPadEvent},save:!0})}loadSample(){let e=M(this.waveform),t=M(this.sampleData);(t||e)&&this.engine.setWaveformData(t||e,Number(this.sampleRate))}envelope(){return{attack:Number(this.attack),decay:Number(this.decay),sustain:Number(this.sustain),release:Number(this.release)}}async loadFile(e){let t=await Q(await e.arrayBuffer());if(!t)return;let n=yt(t.samples);this.sampleName=e.name,this.sampleRate=t.sampleRate,this.sampleLength=t.samples.length,this.sampleData=de(t.samples),this.waveform=de(n),this.engine.setWaveformData(t.samples,t.sampleRate),this.set({sampleName:this.sampleName,sampleRate:this.sampleRate,sampleLength:this.sampleLength,sampleData:this.sampleData,waveform:this.waveform})}count(){return x(Number(this.padCount||8),1,32)}notes(){return Ce((this.padNotes||[]).slice(),this.count())}velocities(){return ce((this.padVelocities||[]).slice(),this.count(),Number(this.velocity))}actions(){return Ne(this.padActions,this.notes(),this.velocities(),this.count())}slices(){return(this.sampleSlices||[]).map((e,t)=>({index:Number(e.index??t),note:Number(e.note),start:Math.max(0,Math.floor(Number(e.start)||0)),end:Math.max(0,Math.floor(Number(e.end)||0)),label:typeof e.label=="string"?e.label:void 0})).filter(e=>Number.isFinite(e.note)&&e.end>e.start)}sliceFor(e){if(e.type!=="note")return;let t=this.slices();return e.slice!==void 0?t.find(n=>n.index===e.slice):t.find(n=>n.note===e.note)}fitPads(){let e=this.notes(),t=this.velocities(),n={};e.length!==(this.padNotes||[]).length&&(this.padNotes=e,n.padNotes=e),t.length!==(this.padVelocities||[]).length&&(this.padVelocities=t,n.padVelocities=t),Object.keys(n).length&&this.emitDetail("nbplay-status",{values:n,save:!1})}pads(){let e=this.velocities();return this.actions().map((t,n)=>{let i=e[n]??100,a=this.sliceFor(t)?.label??(t.type==="note"&&!t.label?void 0:vt(t));return a===void 0?{note:t.note,velocity:i}:{note:this.notes()[n]??60,velocity:i,label:a}})}triggerPad(e,t){let n=this.actions()[e];n&&(this.held.add(e),n.type==="note"?(this.heldNotes.set(e,n.note),this.engine.noteOn(n.note,Number(this.rootNote),this.envelope(),t,this.sliceFor(n)),this.lastNoteEvent={note:n.note,velocity:t,type:"on"},this.lastPadEvent={pad:e,event:"on",velocity:t,action:n}):(n.type==="trait"&&this.set({[n.trait]:n.value}),this.lastPadEvent={pad:e,event:"trigger",velocity:t,action:n}),this.status())}releasePad(e){if(!this.held.delete(e))return;let t=this.heldNotes.get(e),n=this.actions()[e];this.heldNotes.delete(e),t!==void 0&&(this.engine.noteOff(t,{release:Number(this.release)}),this.lastNoteEvent={note:t,velocity:0,type:"off"},n&&(this.lastPadEvent={pad:e,event:"off",velocity:0,action:n})),this.status()}onPadChange(e){e.stopPropagation();let{index:t,field:n,value:i}=e.detail;if(n==="note"){let s=this.notes();if(t>=s.length)return;s[t]=i;let a=this.actions().map((o,l)=>l===t&&o.type==="note"?{...o,note:i}:o);this.padNotes=s,this.padActions=a,this.set({padNotes:s,padActions:a})}else{let s=this.velocities();if(t>=s.length)return;s[t]=i,this.padVelocities=s,this.set({padVelocities:s})}}applyPadCount(e){if(Number.isNaN(e))return;let t=x(Math.round(e),1,32),n=Ce((this.padNotes||[]).slice(),t),i=ce((this.padVelocities||[]).slice(),t,Number(this.velocity)),s=Ne(this.padActions,n,i,t);this.padCount=t,this.padNotes=n,this.padVelocities=i,this.padActions=s,this.set({padCount:t,padNotes:n,padVelocities:i,padActions:s})}onVelocity(e){e.stopPropagation();let t=A(e.detail.value);t!==this.velocity&&(this.velocity=t,this.padVelocities=ce(this.velocities(),this.count(),t),this.set({velocity:t,padVelocities:this.padVelocities}))}zoneList(){return(this.zones||[]).map((e,t)=>({id:String(e.id??t),name:typeof e.name=="string"?e.name:`Zone ${t+1}`,note_low:S(e.note_low,0),note_high:S(e.note_high,127),velocity_low:S(e.velocity_low,0),velocity_high:S(e.velocity_high,127),root_note:S(e.root_note,60),sample_rate:Math.max(1,Number(e.sample_rate)||44100),samples:M(e.data)||new Float32Array(0)}))}writeZones(e){let t=e.map(n=>({id:n.id,name:n.name,note_low:n.note_low,note_high:n.note_high,velocity_low:n.velocity_low,velocity_high:n.velocity_high,root_note:n.root_note,sample_rate:n.sample_rate,length:n.samples.length,data:de(n.samples)}));this.zones=t,this.engine.setZones(e),this.set({zones:t})}addZone(e,t,n,i){let s=this.zoneList();s.push({id:Math.random().toString(36).slice(2,10),name:n,note_low:i.low,note_high:i.high,velocity_low:0,velocity_high:127,root_note:i.root,sample_rate:t,samples:e}),this.writeZones(s)}captureRange(){let e=this.capturePad;if(e>=0){let t=this.notes()[e];if(t!==void 0)return{low:t,high:t,root:t}}return{low:0,high:127,root:60}}onZoneChange(e){e.stopPropagation();let{index:t,field:n,value:i}=e.detail,s=this.zoneList(),a=s[t];if(a){if(n==="name")a.name=String(i).trim()||a.name;else if(n==="low"||n==="high"){let o=n==="low"?"note_low":"note_high",l=S(i,a[o]);a[o]=l,a.note_low>a.note_high&&(n==="low"?a.note_high=l:a.note_low=l)}else a.root_note=S(i,a.root_note);this.writeZones(s)}}async addZoneFromFile(e){let t=await Q(await e.arrayBuffer());t&&(this.addZone(t.samples,t.sampleRate,e.name,this.captureRange()),this.zoneStatus=`Added ${e.name}`)}async command(e){if(e?.url){this.zoneStatus="Capturing\u2026";try{let t=await fetch(e.url),n=await Q(await t.arrayBuffer());if(!n)throw new Error("Web Audio is unavailable");let i=n.samples,s=Math.max(0,Math.floor((e.offset||0)*n.sampleRate)),a=e.duration&&e.duration>0?Math.max(1,Math.round(e.duration*n.sampleRate)):i.length-s;(s>0||s+a<i.length)&&(i=i.slice(s,Math.min(i.length,s+a)));let o=S(e.note_low,0),l=S(e.note_high,127);this.addZone(i,n.sampleRate,e.name||"Take",{low:Math.min(o,l),high:Math.max(o,l),root:S(e.root_note,o)}),this.zoneStatus=`Captured ${e.name||"take"}`}catch(t){this.zoneStatus=`Capture failed: ${t instanceof Error?t.message:String(t)}`}}}async startZoneRecording(){let e=navigator,t=globalThis.MediaRecorder;if(!t||!e.mediaDevices?.getUserMedia){this.zoneStatus="Microphone recording is unavailable";return}try{this.recorderStream=await e.mediaDevices.getUserMedia({audio:!0})}catch(a){this.zoneStatus=`Microphone unavailable: ${a instanceof Error?a.message:String(a)}`;return}let n=this.captureRange(),i=`Take ${this.zoneList().length+1}`;this.recorderChunks=[];let s=new t(this.recorderStream);this.recorder=s,s.addEventListener("dataavailable",a=>{a.data&&a.data.size&&this.recorderChunks.push(a.data)}),s.addEventListener("stop",async()=>{let a=new Blob(this.recorderChunks,{type:s.mimeType||"audio/webm"});if(this.recorderChunks=[],this.recorderStream?.getTracks().forEach(l=>l.stop()),this.recorderStream=null,this.recorder=null,this.recording=!1,!a.size){this.zoneStatus="No audio was captured";return}let o=await Q(await a.arrayBuffer());o&&(this.addZone(o.samples,o.sampleRate,i,n),this.zoneStatus=`Captured ${i}`)}),s.start(),this.recording=!0,this.zoneStatus=`Recording ${i}\u2026`}stopZoneRecording(){this.recorder&&this.recorder.state!=="inactive"&&this.recorder.stop()}onBusReady=e=>{e.detail?.sessionId===this.sessionId&&this.register()};unregister(){if(!this.registration)return;let{bus:e,idx:t,sampler:n,instrument:i}=this.registration;e.samplers?.[t]===n&&delete e.samplers[t],e.instruments?.[t]===i&&delete e.instruments[t],this.registration=null}register(){let e=this.sessionId,t=Number(this.channelIndex);if(this.unregister(),!e||t<0)return;let n=ue(e);if(!n)return;this.engine.setSession(e,t);let i=n.samplers||{};n.samplers=i,i[t]={triggerNote:(a,o)=>{this.engine.noteOn(a,Number(this.rootNote),this.envelope(),o)},releaseNote:a=>{this.engine.noteOff(a,{release:Number(this.release)})}};let s=n.instruments||{};n.instruments=s,s[t]={scheduleNote:(a,o,l,m)=>{let b=this.slices().find(d=>d.note===a),u=this.engine.noteOn(a,Number(this.rootNote),this.envelope(),o,b,l,m);if(u)return()=>this.engine.cancelVoice(u)}},this.registration={bus:n,idx:t,sampler:i[t],instrument:s[t]}}silence(){this.engine.stopAll()}param(e,t,n,i,s,a,o,l,m="slider"){let b=u=>{u.stopPropagation();let d=u.detail.value;d!==this[n]&&(this[n]=d,this.set({[n]:d}))};return h`<nbplay-param
      class=${e}
      .label=${t}
      .kind=${i}
      .control=${m}
      .value=${Number(this[n])}
      .min=${s}
      .max=${a}
      .step=${o}
      .defaultValue=${l}
      @input=${b}
      @change=${b}
    ></nbplay-param>`}render(){let e=i=>i.stopPropagation(),t=this.notes(),n=this.zoneList();return h`<nbplay-header badge="sampler">
        <input
          type="file"
          class="nbplay-samp-file"
          accept="audio/*"
          @change=${i=>{i.stopPropagation();let s=i.target.files?.[0];s&&this.loadFile(s)}}
        />
        <span class="nbplay-samp-name">${this.sampleName}</span>
      </nbplay-header>
      <nbplay-waveform
        class="nbplay-samp-waveform"
        .data=${M(this.waveform)||M(this.sampleData)}
        empty-text="No sample loaded"
        @dragover=${i=>{i.preventDefault(),i.currentTarget.classList.add("drag-over")}}
        @dragleave=${i=>i.currentTarget.classList.remove("drag-over")}
        @drop=${i=>{i.preventDefault(),i.currentTarget.classList.remove("drag-over");let s=i.dataTransfer?.files?.[0];s&&this.loadFile(s)}}
      ></nbplay-waveform>
      <div class="nbplay-samp-info">
        <span class="nbplay-samp-info-rate"
          >${Number(this.sampleRate)/1e3} kHz</span
        >
        <span class="nbplay-samp-info-root"
          >${E(Number(this.rootNote))}</span
        >
        <span class="nbplay-samp-info-len"
          >${kt(Number(this.sampleLength),Number(this.sampleRate))}</span
        >
        <span class="nbplay-samp-info-voices">${this.maxVoices} voices</span>
        <span class="nbplay-samp-active-voices"
          >${this.activeVoices} active</span
        >
      </div>
      <div class="nbplay-samp-envelope">
        <nbplay-envelope
          class="nbplay-samp-env-canvas"
          .attack=${Number(this.attack)}
          .decay=${Number(this.decay)}
          .sustain=${Number(this.sustain)}
          .release=${Number(this.release)}
        ></nbplay-envelope>
        <div class="nbplay-samp-env-controls">
          ${this.param("nbplay-samp-attack","Attack","attack","seconds",0,2,.001,.005,"dial")}
          ${this.param("nbplay-samp-decay","Decay","decay","seconds",0,2,.001,.1,"dial")}
          ${this.param("nbplay-samp-sustain","Sustain","sustain","percent",0,1,.01,.8,"dial")}
          ${this.param("nbplay-samp-release","Release","release","seconds",0,5,.001,.1,"dial")}
        </div>
      </div>
      <div class="nbplay-samp-row">
        ${this.param("nbplay-samp-max-voices","Max Voices","maxVoices","int",1,32,1,8)}
      </div>
      <div class="nbplay-samp-pads-section">
        <div class="nbplay-samp-pads-controls">
          <label class="nbplay-samp-field">
            <span class="nbplay-samp-label">Trigger Pads</span>
            <input
              type="number"
              class="nbplay-samp-pad-count"
              min="1"
              max="32"
              step="1"
              .value=${String(this.count())}
              @change=${e}
              @input=${i=>{i.stopPropagation(),this.applyPadCount(parseInt(i.target.value,10))}}
            />
          </label>
          <nbplay-param
            class="nbplay-samp-velocity"
            label="Velocity"
            kind="int"
            .value=${Number(this.velocity)}
            .min=${1}
            .max=${127}
            .step=${1}
            .defaultValue=${100}
            @input=${this.onVelocity}
            @change=${this.onVelocity}
          ></nbplay-param>
          <label class="nbplay-samp-vel-sense-label">
            <input
              type="checkbox"
              class="nbplay-samp-vel-sense"
              .checked=${this.velocitySensitive}
              @input=${e}
              @change=${i=>{i.stopPropagation(),this.velocitySensitive=i.target.checked,this.set({velocitySensitive:this.velocitySensitive})}}
            />
            Vel-Sensitive
          </label>
        </div>
        <nbplay-pad-grid
          class="nbplay-samp-pads-grid"
          .rows=${Math.ceil(this.count()/4)}
          .cols=${Math.min(4,this.count())}
          .pads=${this.pads()}
          .active=${this.activePads}
          .velocitySensitive=${this.velocitySensitive}
          hold
          @nbplay-note-on=${i=>{i.stopPropagation();let{index:s,velocity:a}=i.detail;this.triggerPad(s,a)}}
          @nbplay-note-off=${i=>{i.stopPropagation(),this.releasePad(i.detail.index)}}
          @input=${this.onPadChange}
          @change=${this.onPadChange}
        ></nbplay-pad-grid>
      </div>
      <div class="nbplay-samp-zones-section">
        <div class="nbplay-samp-zones-controls">
          <span class="nbplay-samp-label">Zones</span>
          <select
            class="nbplay-samp-zone-pad"
            title="Pad a captured sample lands on"
            @input=${e}
            @change=${i=>{i.stopPropagation(),this.capturePad=Number(i.target.value)}}
          >
            <option value="-1" ?selected=${this.capturePad<0}>
              All notes
            </option>
            ${t.map((i,s)=>h`<option
                  value=${s}
                  ?selected=${s===this.capturePad}
                  .textContent=${`Pad ${s+1} (${E(i)})`}
                ></option>`)}
          </select>
          <label
            class="nbplay-samp-zone-file-label"
            title="Add a zone from an audio file"
          >
            File<input
              type="file"
              class="nbplay-samp-zone-file"
              accept="audio/*"
              @change=${i=>{i.stopPropagation();let s=i.target,a=s.files?.[0];a&&(this.addZoneFromFile(a),s.value="")}}
            />
          </label>
          <button
            type="button"
            class="nbplay-samp-zone-rec ${this.recording?"recording":""}"
            title="Record the microphone into the selected pad"
            @click=${()=>{this.recorder?this.stopZoneRecording():this.startZoneRecording()}}
          >
            ${this.recording?"Stop":"Rec"}
          </button>
          <span class="nbplay-samp-zone-status">${this.zoneStatus}</span>
        </div>
        <nbplay-zone-map
          .zones=${n.map(i=>({low:i.note_low,high:i.note_high,name:i.name}))}
        ></nbplay-zone-map>
        <nbplay-zone-list
          .zones=${n.map(i=>({name:i.name,low:i.note_low,high:i.note_high,root:i.root_note,info:kt(i.samples.length,i.sample_rate)}))}
          @input=${e}
          @change=${this.onZoneChange}
          @nbplay-zone-remove=${i=>{i.stopPropagation();let s=this.zoneList();s.splice(i.detail.index,1),this.writeZones(s)}}
        ></nbplay-zone-list>
      </div>`}};g("nbplay-sampler",He);function tn({model:r,el:e}){let t=document.createElement("nbplay-sampler");return Ge(r,e,t,{config:{theme:"theme",sample_name:"sampleName",sample_rate:"sampleRate",sample_length:"sampleLength",root_note:"rootNote",waveform:"waveform",sample_data:"sampleData",attack:"attack",decay:"decay",sustain:"sustain",release:"release",max_voices:"maxVoices",pad_count:"padCount",pad_notes:"padNotes",pad_velocities:"padVelocities",pad_actions:"padActions",sample_slices:"sampleSlices",velocity:"velocity",velocity_sensitive:"velocitySensitive",zones:"zones",session_id:"sessionId",channel_index:"channelIndex"},status:{active_pads:"activePads",last_note_event:"lastNoteEvent",last_pad_event:"lastPadEvent"},command:"capture_request",onDisconnect:()=>t.silence()})}var Hi={render:tn};export{Hi as default};
/*! Bundled license information:

@lit/reactive-element/css-tag.js:
  (**
   * @license
   * Copyright 2019 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/reactive-element.js:
lit-html/lit-html.js:
lit-element/lit-element.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/is-server.js:
  (**
   * @license
   * Copyright 2022 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
//# sourceMappingURL=sampler.js.map
