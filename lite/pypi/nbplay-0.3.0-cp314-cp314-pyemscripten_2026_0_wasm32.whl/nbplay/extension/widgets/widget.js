function w(e,a,r=5e3){let n=e,s=null,t=null,u=!1;if(!("comm"in n||"widget_manager"in n))return()=>{};function c(){return"comm"in n?n.comm!=null:n.widget_manager!=null}return s=setInterval(()=>{u||(!c()&&!t?t=setTimeout(()=>{!c()&&!u&&(u=!0,a()),t=null},r):c()&&t&&(clearTimeout(t),t=null))},2e3),()=>{s&&(clearInterval(s),s=null),t&&(clearTimeout(t),t=null)}}function b(e,a,r){return getComputedStyle(e).getPropertyValue(a).trim()||r}function E(e){let a=globalThis,r=a.AudioContext||a.webkitAudioContext;if(!r)return null;try{return new r(e)}catch{try{return new r}catch{return null}}}function h(e,a){e.style.cursor="pointer",e.title="Double-click to edit",e.addEventListener("dblclick",()=>{let r=!1,n=document.createElement("input");n.type="text",n.className=a.className??"nbplay-inline-edit",n.value=a.getValue(),n.style.width=Math.max(e.offsetWidth+8,48)+"px",e.replaceWith(n),n.focus(),n.select();function s(){if(r)return;r=!0;let t=a.parse(n.value.trim());t!==null&&a.apply(t),n.replaceWith(e),a.sync()}n.addEventListener("keydown",t=>{t.key==="Enter"&&(t.preventDefault(),s()),t.key==="Escape"&&(t.preventDefault(),r||(r=!0,n.replaceWith(e),a.sync()))}),n.addEventListener("blur",s)})}function q(e){if(!e||!e.byteLength)return null;if(e instanceof DataView){let a=e.byteLength/4,r=new Float32Array(a);for(let n=0;n<a;n++)r[n]=e.getFloat32(n*4,!0);return r}if(e.buffer instanceof ArrayBuffer){let a=e;return new Float32Array(a.buffer.slice(a.byteOffset,a.byteOffset+a.byteLength))}return e instanceof ArrayBuffer?new Float32Array(e):null}var g=20,L=8e3,C=Math.log(L/g);function S(e){return Math.log(Math.max(g,Math.min(L,e))/g)/C}function _(e){return g*Math.exp(C*Math.max(0,Math.min(1,e)))}function F(e){return e>=1e3?(e/1e3).toFixed(2)+" kHz":e.toFixed(1)+" Hz"}function N(e,a){let r=window.devicePixelRatio||1,n=e.clientWidth||600,s=e.clientHeight||128;e.width=n*r,e.height=s*r;let t=e.getContext("2d");t.scale(r,r);let u=b(e,"--jp-layout-color0","#080812"),l=b(e,"--jp-brand-color1","#00d4ff"),c=b(e,"--jp-ui-font-color3","#64648a");if(t.fillStyle=u,t.fillRect(0,0,n,s),t.strokeStyle=c,t.globalAlpha=.35,t.lineWidth=1,t.setLineDash([4,4]),t.beginPath(),t.moveTo(0,s/2),t.lineTo(n,s/2),t.stroke(),t.setLineDash([]),t.globalAlpha=.15,t.beginPath(),t.moveTo(0,s*.25),t.lineTo(n,s*.25),t.moveTo(0,s*.75),t.lineTo(n,s*.75),t.stroke(),t.globalAlpha=1,!a||a.length===0)return;let p=a.length/n;t.strokeStyle=l,t.globalAlpha=.25,t.lineWidth=6,t.lineCap="round",t.lineJoin="round",t.beginPath();for(let i=0;i<n;i++){let y=(1-a[Math.min(Math.floor(i*p),a.length-1)])*s/2;i===0?t.moveTo(i,y):t.lineTo(i,y)}t.stroke(),t.globalAlpha=1,t.strokeStyle=l,t.lineWidth=2,t.beginPath();for(let i=0;i<n;i++){let y=(1-a[Math.min(Math.floor(i*p),a.length-1)])*s/2;i===0?t.moveTo(i,y):t.lineTo(i,y)}t.stroke()}function H(){let e=null,a=null,r=null;return{start(n,s,t,u){if(this.stop(),e=E({sampleRate:u}),!e)return!1;if(e.state==="suspended"&&e.resume?.(),r=e.createGain(),r.gain.value=t,r.connect(e.destination),n==="noise"){let l=e.createBuffer(1,u*2,u),c=l.getChannelData(0);for(let i=0;i<c.length;i++)c[i]=Math.random()*2-1;let p=e.createBufferSource();p.buffer=l,p.loop=!0,p.connect(r),p.start(),a=p}else{let l=e.createOscillator();l.type=n==="saw"?"sawtooth":n,l.frequency.value=s,l.connect(r),l.start(),a=l}return!0},stop(){if(a){try{a.stop()}catch{}a.disconnect(),a=null}r&&(r.disconnect(),r=null),e&&(e.close(),e=null)},setFrequency(n){a&&a.frequency&&e&&a.frequency.setTargetAtTime(n,e.currentTime,.01)},setAmplitude(n){r&&e&&r.gain.setTargetAtTime(n,e.currentTime,.01)}}}function B({model:e,el:a}){let r=H(),n=document.createElement("div");n.className="nbplay-synth",n.innerHTML=`
    <div class="nbplay-header">
      <h3>nbplay</h3>
      <span class="nbplay-badge">synth</span>
    </div>

    <div class="nbplay-waveform-container">
      <canvas class="nbplay-waveform"></canvas>
    </div>

    <div class="nbplay-osc-selector">
      <span class="nbplay-label">Oscillator</span>
      <div class="nbplay-osc-buttons">
        <button class="nbplay-osc-btn" data-type="sine">Sine</button>
        <button class="nbplay-osc-btn" data-type="square">Square</button>
        <button class="nbplay-osc-btn" data-type="saw">Saw</button>
        <button class="nbplay-osc-btn" data-type="noise">Noise</button>
      </div>
    </div>

    <div class="nbplay-params">
      <div class="nbplay-param">
        <span class="nbplay-label">Frequency</span>
        <input type="range" class="nbplay-freq" min="0" max="1" step="0.001" />
        <span class="nbplay-value nbplay-freq-val"></span>
      </div>
      <div class="nbplay-param">
        <span class="nbplay-label">Amplitude</span>
        <input type="range" class="nbplay-amp" min="0" max="1" step="0.01" />
        <span class="nbplay-value nbplay-amp-val"></span>
      </div>
    </div>

    <div class="nbplay-transport">
      <button class="nbplay-play-btn"></button>
      <span class="nbplay-info"></span>
    </div>
  `,a.appendChild(n);let s=n.querySelector(".nbplay-waveform"),t=n.querySelectorAll(".nbplay-osc-btn"),u=n.querySelector(".nbplay-freq"),l=n.querySelector(".nbplay-freq-val"),c=n.querySelector(".nbplay-amp"),p=n.querySelector(".nbplay-amp-val"),i=n.querySelector(".nbplay-play-btn"),y=n.querySelector(".nbplay-info");function x(){let o=e.get("oscillator_type");t.forEach(T=>T.classList.toggle("active",T.dataset.type===o));let f=o==="noise";u.disabled=f}function m(){let o=e.get("frequency");u.value=String(S(o)),l.textContent=F(o)}function v(){let o=e.get("amplitude");c.value=String(o),p.textContent=o.toFixed(2)}function d(){let o=e.get("is_playing");i.textContent=o?"\u25A0  Stop":"\u25B6  Play",i.classList.toggle("playing",o)}h(l,{getValue:()=>String(e.get("frequency")),parse:o=>{let f=parseFloat(o);return isNaN(f)?null:(o.toLowerCase().includes("k")&&(f*=1e3),Math.max(20,Math.min(8e3,Math.round(f*10)/10)))},apply:o=>{e.set("frequency",o),e.save_changes(),r.setFrequency(o)},sync:m}),h(p,{getValue:()=>String(e.get("amplitude")),parse:o=>{let f=parseFloat(o);return isNaN(f)?null:Math.max(0,Math.min(1,Math.round(f*100)/100))},apply:o=>{e.set("amplitude",o),e.save_changes(),r.setAmplitude(o)},sync:v});function M(){y.textContent=e.get("sample_rate")+" Hz"}function A(){let o=e.get("waveform");N(s,q(o))}t.forEach(o=>o.addEventListener("click",()=>{e.set("oscillator_type",o.dataset.type),e.save_changes(),e.get("is_playing")&&r.start(o.dataset.type,e.get("frequency"),e.get("amplitude"),e.get("sample_rate"))})),u.addEventListener("input",()=>{let o=Math.round(_(parseFloat(u.value))*10)/10;e.set("frequency",o),e.save_changes(),r.setFrequency(o)}),c.addEventListener("input",()=>{let o=Math.round(parseFloat(c.value)*100)/100;e.set("amplitude",o),e.save_changes(),r.setAmplitude(o)}),i.addEventListener("click",()=>{e.set("is_playing",!e.get("is_playing")),e.save_changes()}),e.on("change:oscillator_type",x),e.on("change:frequency",m),e.on("change:amplitude",v),e.on("change:is_playing",()=>{d(),e.get("is_playing")?r.start(e.get("oscillator_type"),e.get("frequency"),e.get("amplitude"),e.get("sample_rate"))||(e.set("is_playing",!1),e.save_changes(),d()):r.stop()}),e.on("change:sample_rate",M),e.on("change:waveform",A),e.set("is_playing",!1),x(),m(),v(),d(),M(),requestAnimationFrame(A);let k=w(e,()=>{e.set("is_playing",!1),r.stop(),d()});return()=>{k(),r.stop()}}var I={render:B};export{I as default};
//# sourceMappingURL=widget.js.map
