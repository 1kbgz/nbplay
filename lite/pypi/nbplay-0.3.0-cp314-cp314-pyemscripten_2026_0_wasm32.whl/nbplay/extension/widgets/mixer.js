function Ue(i,e,t=5e3){let n=i,r=null,s=null,a=!1;if(!("comm"in n||"widget_manager"in n))return()=>{};function u(){return"comm"in n?n.comm!=null:n.widget_manager!=null}return r=setInterval(()=>{a||(!u()&&!s?s=setTimeout(()=>{!u()&&!a&&(a=!0,e()),s=null},t):u()&&s&&(clearTimeout(s),s=null))},2e3),()=>{r&&(clearInterval(r),r=null),s&&(clearTimeout(s),s=null)}}function q(i){let e=globalThis,t=e.AudioContext||e.webkitAudioContext;if(!t)return null;try{return new t(i)}catch{try{return new t}catch{return null}}}function Ie(i){return i<=0?-1/0:20*Math.log10(i)}function St(i){return Math.pow(10,i/20)}function ne(i){if(i<=0)return"\u2212\u221E dB";let e=20*Math.log10(i);return e>=0?"+"+e.toFixed(1)+" dB":e.toFixed(1)+" dB"}function Ve(i){return Math.abs(i)<.01?"C":i<0?"L"+Math.round(Math.abs(i)*100):"R"+Math.round(i*100)}function He(i){let e=i.replace(/\s*db\s*$/i,"").trim();if(e==="\u2212\u221E"||e==="-inf"||e==="-Infinity")return 0;let t=parseFloat(e);if(isNaN(t))return null;let n=St(t);return Math.max(0,Math.min(2,Math.round(n*1e3)/1e3))}function wt(i){return i.replace(/[A-Z]/g,e=>"_"+e.toLowerCase())}function Ge(i,e,t,n){let r=t,s=(l,d)=>{let b=i.get(l);return d==="sessionId"?String(b||""):b};for(let[l,d]of Object.entries(n.config))r[d]=s(l,d);let a=!1,o=!1;function u(l,d){a=!0;try{for(let[b,x]of Object.entries(l))i.set(wt(b),x)}finally{a=!1}d&&!o&&i.save_changes()}t.addEventListener("nbplay-set",l=>{u(l.detail.values,!0)}),t.addEventListener("nbplay-status",l=>{let{values:d,save:b}=l.detail;u(d,!!b)}),t.addEventListener("nbplay-request",l=>{let d=`${l.detail.name}_request`;i.set(d,(Number(i.get(d))||0)+1),o||i.save_changes()}),e.appendChild(t);let h={};for(let l of Object.values(n.status))h[l]=r[l];u(h,!1);for(let[l,d]of Object.entries(n.config))i.on(`change:${l}`,()=>{a||(r[d]=s(l,d))});for(let[l,d]of Object.entries(n.status))i.on(`change:${l}`,()=>{a||(r[d]=i.get(l))});if(n.command){let l=n.command===!0?"command":n.command,d=Number(i.get(l)?.nonce??-1);Number.isFinite(d)||(d=-1),i.on(`change:${l}`,()=>{let b=i.get(l)||{},x=Number(b.nonce);if(Number.isFinite(x)){if(x<=d)return;d=x}t.command?.(b)})}let m=Ue(i,()=>{o=!0,n.onDisconnect?.()});return()=>{m(),t.remove()}}var W=globalThis,J=W.ShadowRoot&&(W.ShadyCSS===void 0||W.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,Ke=Symbol(),ze=new WeakMap,Y=class{constructor(e,t,n){if(this._$cssResult$=!0,n!==Ke)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=e,this.t=t}get styleSheet(){let e=this.o,t=this.t;if(J&&e===void 0){let n=t!==void 0&&t.length===1;n&&(e=ze.get(t)),e===void 0&&((this.o=e=new CSSStyleSheet).replaceSync(this.cssText),n&&ze.set(t,e))}return e}toString(){return this.cssText}},je=i=>new Y(typeof i=="string"?i:i+"",void 0,Ke);var qe=(i,e)=>{if(J)i.adoptedStyleSheets=e.map(t=>t instanceof CSSStyleSheet?t:t.styleSheet);else for(let t of e){let n=document.createElement("style"),r=W.litNonce;r!==void 0&&n.setAttribute("nonce",r),n.textContent=t.cssText,i.appendChild(n)}},ie=J?i=>i:i=>i instanceof CSSStyleSheet?(e=>{let t="";for(let n of e.cssRules)t+=n.cssText;return je(t)})(i):i;var{is:Nt,defineProperty:Mt,getOwnPropertyDescriptor:Pt,getOwnPropertyNames:Dt,getOwnPropertySymbols:Tt,getPrototypeOf:Bt}=Object,Z=globalThis,We=Z.trustedTypes,Rt=We?We.emptyScript:"",Lt=Z.reactiveElementPolyfillSupport,U=(i,e)=>i,re={toAttribute(i,e){switch(e){case Boolean:i=i?Rt:null;break;case Object:case Array:i=i==null?i:JSON.stringify(i)}return i},fromAttribute(i,e){let t=i;switch(e){case Boolean:t=i!==null;break;case Number:t=i===null?null:Number(i);break;case Object:case Array:try{t=JSON.parse(i)}catch{t=null}}return t}},Je=(i,e)=>!Nt(i,e),Ye={attribute:!0,type:String,converter:re,reflect:!1,useDefault:!1,hasChanged:Je};Symbol.metadata??=Symbol("metadata"),Z.litPropertyMetadata??=new WeakMap;var S=class extends HTMLElement{static addInitializer(e){this._$Ei(),(this.l??=[]).push(e)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(e,t=Ye){if(t.state&&(t.attribute=!1),this._$Ei(),this.prototype.hasOwnProperty(e)&&((t=Object.create(t)).wrapped=!0),this.elementProperties.set(e,t),!t.noAccessor){let n=Symbol(),r=this.getPropertyDescriptor(e,n,t);r!==void 0&&Mt(this.prototype,e,r)}}static getPropertyDescriptor(e,t,n){let{get:r,set:s}=Pt(this.prototype,e)??{get(){return this[t]},set(a){this[t]=a}};return{get:r,set(a){let o=r?.call(this);s?.call(this,a),this.requestUpdate(e,o,n)},configurable:!0,enumerable:!0}}static getPropertyOptions(e){return this.elementProperties.get(e)??Ye}static _$Ei(){if(this.hasOwnProperty(U("elementProperties")))return;let e=Bt(this);e.finalize(),e.l!==void 0&&(this.l=[...e.l]),this.elementProperties=new Map(e.elementProperties)}static finalize(){if(this.hasOwnProperty(U("finalized")))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(U("properties"))){let t=this.properties,n=[...Dt(t),...Tt(t)];for(let r of n)this.createProperty(r,t[r])}let e=this[Symbol.metadata];if(e!==null){let t=litPropertyMetadata.get(e);if(t!==void 0)for(let[n,r]of t)this.elementProperties.set(n,r)}this._$Eh=new Map;for(let[t,n]of this.elementProperties){let r=this._$Eu(t,n);r!==void 0&&this._$Eh.set(r,t)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(e){let t=[];if(Array.isArray(e)){let n=new Set(e.flat(1/0).reverse());for(let r of n)t.unshift(ie(r))}else e!==void 0&&t.push(ie(e));return t}static _$Eu(e,t){let n=t.attribute;return n===!1?void 0:typeof n=="string"?n:typeof e=="string"?e.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){this._$ES=new Promise(e=>this.enableUpdating=e),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach(e=>e(this))}addController(e){(this._$EO??=new Set).add(e),this.renderRoot!==void 0&&this.isConnected&&e.hostConnected?.()}removeController(e){this._$EO?.delete(e)}_$E_(){let e=new Map,t=this.constructor.elementProperties;for(let n of t.keys())this.hasOwnProperty(n)&&(e.set(n,this[n]),delete this[n]);e.size>0&&(this._$Ep=e)}createRenderRoot(){let e=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return qe(e,this.constructor.elementStyles),e}connectedCallback(){this.renderRoot??=this.createRenderRoot(),this.enableUpdating(!0),this._$EO?.forEach(e=>e.hostConnected?.())}enableUpdating(e){}disconnectedCallback(){this._$EO?.forEach(e=>e.hostDisconnected?.())}attributeChangedCallback(e,t,n){this._$AK(e,n)}_$ET(e,t){let n=this.constructor.elementProperties.get(e),r=this.constructor._$Eu(e,n);if(r!==void 0&&n.reflect===!0){let s=(n.converter?.toAttribute!==void 0?n.converter:re).toAttribute(t,n.type);this._$Em=e,s==null?this.removeAttribute(r):this.setAttribute(r,s),this._$Em=null}}_$AK(e,t){let n=this.constructor,r=n._$Eh.get(e);if(r!==void 0&&this._$Em!==r){let s=n.getPropertyOptions(r),a=typeof s.converter=="function"?{fromAttribute:s.converter}:s.converter?.fromAttribute!==void 0?s.converter:re;this._$Em=r;let o=a.fromAttribute(t,s.type);this[r]=o??this._$Ej?.get(r)??o,this._$Em=null}}requestUpdate(e,t,n,r=!1,s){if(e!==void 0){let a=this.constructor;if(r===!1&&(s=this[e]),n??=a.getPropertyOptions(e),!((n.hasChanged??Je)(s,t)||n.useDefault&&n.reflect&&s===this._$Ej?.get(e)&&!this.hasAttribute(a._$Eu(e,n))))return;this.C(e,t,n)}this.isUpdatePending===!1&&(this._$ES=this._$EP())}C(e,t,{useDefault:n,reflect:r,wrapped:s},a){n&&!(this._$Ej??=new Map).has(e)&&(this._$Ej.set(e,a??t??this[e]),s!==!0||a!==void 0)||(this._$AL.has(e)||(this.hasUpdated||n||(t=void 0),this._$AL.set(e,t)),r===!0&&this._$Em!==e&&(this._$Eq??=new Set).add(e))}async _$EP(){this.isUpdatePending=!0;try{await this._$ES}catch(t){Promise.reject(t)}let e=this.scheduleUpdate();return e!=null&&await e,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??=this.createRenderRoot(),this._$Ep){for(let[r,s]of this._$Ep)this[r]=s;this._$Ep=void 0}let n=this.constructor.elementProperties;if(n.size>0)for(let[r,s]of n){let{wrapped:a}=s,o=this[r];a!==!0||this._$AL.has(r)||o===void 0||this.C(r,void 0,s,o)}}let e=!1,t=this._$AL;try{e=this.shouldUpdate(t),e?(this.willUpdate(t),this._$EO?.forEach(n=>n.hostUpdate?.()),this.update(t)):this._$EM()}catch(n){throw e=!1,this._$EM(),n}e&&this._$AE(t)}willUpdate(e){}_$AE(e){this._$EO?.forEach(t=>t.hostUpdated?.()),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(e)),this.updated(e)}_$EM(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(e){return!0}update(e){this._$Eq&&=this._$Eq.forEach(t=>this._$ET(t,this[t])),this._$EM()}updated(e){}firstUpdated(e){}};S.elementStyles=[],S.shadowRootOptions={mode:"open"},S[U("elementProperties")]=new Map,S[U("finalized")]=new Map,Lt?.({ReactiveElement:S}),(Z.reactiveElementVersions??=[]).push("2.1.2");var de=globalThis,Ze=i=>i,X=de.trustedTypes,Xe=X?X.createPolicy("lit-html",{createHTML:i=>i}):void 0,rt="$lit$",N=`lit$${Math.random().toFixed(9).slice(2)}$`,st="?"+N,Ft=`<${st}>`,T=document,V=()=>T.createComment(""),H=i=>i===null||typeof i!="object"&&typeof i!="function",pe=Array.isArray,Ot=i=>pe(i)||typeof i?.[Symbol.iterator]=="function",se=`[ 	
\f\r]`,I=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,Qe=/-->/g,et=/>/g,P=RegExp(`>|${se}(?:([^\\s"'>=/]+)(${se}*=${se}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`,"g"),tt=/'/g,nt=/"/g,at=/^(?:script|style|textarea|title)$/i,he=i=>(e,...t)=>({_$litType$:i,strings:e,values:t}),p=he(1),K=he(2),un=he(3),B=Symbol.for("lit-noChange"),f=Symbol.for("lit-nothing"),it=new WeakMap,D=T.createTreeWalker(T,129);function ot(i,e){if(!pe(i)||!i.hasOwnProperty("raw"))throw Error("invalid template strings array");return Xe!==void 0?Xe.createHTML(e):e}var Ut=(i,e)=>{let t=i.length-1,n=[],r,s=e===2?"<svg>":e===3?"<math>":"",a=I;for(let o=0;o<t;o++){let u=i[o],h,m,l=-1,d=0;for(;d<u.length&&(a.lastIndex=d,m=a.exec(u),m!==null);)d=a.lastIndex,a===I?m[1]==="!--"?a=Qe:m[1]!==void 0?a=et:m[2]!==void 0?(at.test(m[2])&&(r=RegExp("</"+m[2],"g")),a=P):m[3]!==void 0&&(a=P):a===P?m[0]===">"?(a=r??I,l=-1):m[1]===void 0?l=-2:(l=a.lastIndex-m[2].length,h=m[1],a=m[3]===void 0?P:m[3]==='"'?nt:tt):a===nt||a===tt?a=P:a===Qe||a===et?a=I:(a=P,r=void 0);let b=a===P&&i[o+1].startsWith("/>")?" ":"";s+=a===I?u+Ft:l>=0?(n.push(h),u.slice(0,l)+rt+u.slice(l)+N+b):u+N+(l===-2?o:b)}return[ot(i,s+(i[t]||"<?>")+(e===2?"</svg>":e===3?"</math>":"")),n]},G=class i{constructor({strings:e,_$litType$:t},n){let r;this.parts=[];let s=0,a=0,o=e.length-1,u=this.parts,[h,m]=Ut(e,t);if(this.el=i.createElement(h,n),D.currentNode=this.el.content,t===2||t===3){let l=this.el.content.firstChild;l.replaceWith(...l.childNodes)}for(;(r=D.nextNode())!==null&&u.length<o;){if(r.nodeType===1){if(r.hasAttributes())for(let l of r.getAttributeNames())if(l.endsWith(rt)){let d=m[a++],b=r.getAttribute(l).split(N),x=/([.?@])?(.*)/.exec(d);u.push({type:1,index:s,name:x[2],strings:b,ctor:x[1]==="."?oe:x[1]==="?"?le:x[1]==="@"?ue:F}),r.removeAttribute(l)}else l.startsWith(N)&&(u.push({type:6,index:s}),r.removeAttribute(l));if(at.test(r.tagName)){let l=r.textContent.split(N),d=l.length-1;if(d>0){r.textContent=X?X.emptyScript:"";for(let b=0;b<d;b++)r.append(l[b],V()),D.nextNode(),u.push({type:2,index:++s});r.append(l[d],V())}}}else if(r.nodeType===8)if(r.data===st)u.push({type:2,index:s});else{let l=-1;for(;(l=r.data.indexOf(N,l+1))!==-1;)u.push({type:7,index:s}),l+=N.length-1}s++}}static createElement(e,t){let n=T.createElement("template");return n.innerHTML=e,n}};function L(i,e,t=i,n){if(e===B)return e;let r=n!==void 0?t._$Co?.[n]:t._$Cl,s=H(e)?void 0:e._$litDirective$;return r?.constructor!==s&&(r?._$AO?.(!1),s===void 0?r=void 0:(r=new s(i),r._$AT(i,t,n)),n!==void 0?(t._$Co??=[])[n]=r:t._$Cl=r),r!==void 0&&(e=L(i,r._$AS(i,e.values),r,n)),e}var ae=class{constructor(e,t){this._$AV=[],this._$AN=void 0,this._$AD=e,this._$AM=t}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(e){let{el:{content:t},parts:n}=this._$AD,r=(e?.creationScope??T).importNode(t,!0);D.currentNode=r;let s=D.nextNode(),a=0,o=0,u=n[0];for(;u!==void 0;){if(a===u.index){let h;u.type===2?h=new z(s,s.nextSibling,this,e):u.type===1?h=new u.ctor(s,u.name,u.strings,this,e):u.type===6&&(h=new ce(s,this,e)),this._$AV.push(h),u=n[++o]}a!==u?.index&&(s=D.nextNode(),a++)}return D.currentNode=T,r}p(e){let t=0;for(let n of this._$AV)n!==void 0&&(n.strings!==void 0?(n._$AI(e,n,t),t+=n.strings.length-2):n._$AI(e[t])),t++}},z=class i{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(e,t,n,r){this.type=2,this._$AH=f,this._$AN=void 0,this._$AA=e,this._$AB=t,this._$AM=n,this.options=r,this._$Cv=r?.isConnected??!0}get parentNode(){let e=this._$AA.parentNode,t=this._$AM;return t!==void 0&&e?.nodeType===11&&(e=t.parentNode),e}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(e,t=this){e=L(this,e,t),H(e)?e===f||e==null||e===""?(this._$AH!==f&&this._$AR(),this._$AH=f):e!==this._$AH&&e!==B&&this._(e):e._$litType$!==void 0?this.$(e):e.nodeType!==void 0?this.T(e):Ot(e)?this.k(e):this._(e)}O(e){return this._$AA.parentNode.insertBefore(e,this._$AB)}T(e){this._$AH!==e&&(this._$AR(),this._$AH=this.O(e))}_(e){this._$AH!==f&&H(this._$AH)?this._$AA.nextSibling.data=e:this.T(T.createTextNode(e)),this._$AH=e}$(e){let{values:t,_$litType$:n}=e,r=typeof n=="number"?this._$AC(e):(n.el===void 0&&(n.el=G.createElement(ot(n.h,n.h[0]),this.options)),n);if(this._$AH?._$AD===r)this._$AH.p(t);else{let s=new ae(r,this),a=s.u(this.options);s.p(t),this.T(a),this._$AH=s}}_$AC(e){let t=it.get(e.strings);return t===void 0&&it.set(e.strings,t=new G(e)),t}k(e){pe(this._$AH)||(this._$AH=[],this._$AR());let t=this._$AH,n,r=0;for(let s of e)r===t.length?t.push(n=new i(this.O(V()),this.O(V()),this,this.options)):n=t[r],n._$AI(s),r++;r<t.length&&(this._$AR(n&&n._$AB.nextSibling,r),t.length=r)}_$AR(e=this._$AA.nextSibling,t){for(this._$AP?.(!1,!0,t);e!==this._$AB;){let n=Ze(e).nextSibling;Ze(e).remove(),e=n}}setConnected(e){this._$AM===void 0&&(this._$Cv=e,this._$AP?.(e))}},F=class{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(e,t,n,r,s){this.type=1,this._$AH=f,this._$AN=void 0,this.element=e,this.name=t,this._$AM=r,this.options=s,n.length>2||n[0]!==""||n[1]!==""?(this._$AH=Array(n.length-1).fill(new String),this.strings=n):this._$AH=f}_$AI(e,t=this,n,r){let s=this.strings,a=!1;if(s===void 0)e=L(this,e,t,0),a=!H(e)||e!==this._$AH&&e!==B,a&&(this._$AH=e);else{let o=e,u,h;for(e=s[0],u=0;u<s.length-1;u++)h=L(this,o[n+u],t,u),h===B&&(h=this._$AH[u]),a||=!H(h)||h!==this._$AH[u],h===f?e=f:e!==f&&(e+=(h??"")+s[u+1]),this._$AH[u]=h}a&&!r&&this.j(e)}j(e){e===f?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,e??"")}},oe=class extends F{constructor(){super(...arguments),this.type=3}j(e){this.element[this.name]=e===f?void 0:e}},le=class extends F{constructor(){super(...arguments),this.type=4}j(e){this.element.toggleAttribute(this.name,!!e&&e!==f)}},ue=class extends F{constructor(e,t,n,r,s){super(e,t,n,r,s),this.type=5}_$AI(e,t=this){if((e=L(this,e,t,0)??f)===B)return;let n=this._$AH,r=e===f&&n!==f||e.capture!==n.capture||e.once!==n.once||e.passive!==n.passive,s=e!==f&&(n===f||r);r&&this.element.removeEventListener(this.name,this,n),s&&this.element.addEventListener(this.name,this,e),this._$AH=e}handleEvent(e){typeof this._$AH=="function"?this._$AH.call(this.options?.host??this.element,e):this._$AH.handleEvent(e)}},ce=class{constructor(e,t,n){this.element=e,this.type=6,this._$AN=void 0,this._$AM=t,this.options=n}get _$AU(){return this._$AM._$AU}_$AI(e){L(this,e)}};var It=de.litHtmlPolyfillSupport;It?.(G,z),(de.litHtmlVersions??=[]).push("3.3.3");var lt=(i,e,t)=>{let n=t?.renderBefore??e,r=n._$litPart$;if(r===void 0){let s=t?.renderBefore??null;n._$litPart$=r=new z(e.insertBefore(V(),s),s,void 0,t??{})}return r._$AI(i),r};var fe=globalThis,M=class extends S{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){let e=super.createRenderRoot();return this.renderOptions.renderBefore??=e.firstChild,e}update(e){let t=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(e),this._$Do=lt(t,this.renderRoot,this.renderOptions)}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0)}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1)}render(){return B}};M._$litElement$=!0,M.finalized=!0,fe.litElementHydrateSupport?.({LitElement:M});var Vt=fe.litElementPolyfillSupport;Vt?.({LitElement:M});(fe.litElementVersions??=[]).push("4.2.2");var w=["gain","filter","compressor","limiter","delay","reverb"],Ht=["lowpass","highpass","bandpass","notch","lowshelf","highshelf","peaking"],Gt={gain:[{key:"gain",label:"Gain",min:0,max:4,step:.01,default:1,kind:"number"}],filter:[{key:"filter_type",label:"Type",options:Ht,kind:"select"},{key:"frequency",label:"Hz",min:20,max:2e4,step:1,default:1200,kind:"number"},{key:"q",label:"Q",min:1e-4,max:100,step:.01,default:1,kind:"number"}],delay:[{key:"time",label:"Time",min:0,max:5,step:.001,default:.25,kind:"number"},{key:"feedback",label:"Fdbk",min:0,max:.95,step:.01,default:.25,kind:"number"},{key:"wet",label:"Wet",min:0,max:1,step:.01,default:.35,kind:"number"}],reverb:[{key:"seconds",label:"Size",min:.01,max:10,step:.01,default:1.5,kind:"number"},{key:"decay",label:"Decay",min:.01,max:12,step:.01,default:2,kind:"number"},{key:"wet",label:"Wet",min:0,max:1,step:.01,default:.25,kind:"number"}],compressor:[{key:"threshold",label:"Thresh",min:-100,max:0,step:.5,default:-24,kind:"number"},{key:"knee",label:"Knee",min:0,max:40,step:.5,default:30,kind:"number"},{key:"ratio",label:"Ratio",min:1,max:20,step:.1,default:12,kind:"number"},{key:"attack",label:"Attack",min:0,max:1,step:.001,default:.003,kind:"number"},{key:"release",label:"Release",min:0,max:1,step:.001,default:.25,kind:"number"}],limiter:[{key:"threshold",label:"Thresh",min:-100,max:0,step:.5,default:-1,kind:"number"},{key:"release",label:"Release",min:0,max:1,step:.001,default:.05,kind:"number"}]};function me(i){let e=Gt[i.type];return e||Object.entries(i).filter(([t])=>t!=="type"&&t!=="enabled").map(([t,n])=>typeof n=="number"?{key:t,label:t,kind:"number"}:typeof n=="boolean"?{key:t,label:t,kind:"bool"}:typeof n=="string"?{key:t,label:t,kind:"text"}:null).filter(t=>t!==null)}function ut(i){return i.enabled!==!1}function ct(i){return i.type==="filter"?`${i.filter_type||"filter"} ${Math.round(Number(i.frequency)||0)}Hz`:i.type}function zt(){let i=globalThis;return(!i.__nbplay||typeof i.__nbplay!="object")&&(i.__nbplay={}),i.__nbplay}function be(i){return i?globalThis.__nbplay?.[i]:void 0}function dt(i){let e=zt();return e[i]||(e[i]={}),e[i]}function pt(i){if(i.audioCtx&&i.audioCtx.state!=="closed")return i.audioCtx;let e=q();return e&&(i.audioCtx=e),e}function ke(i,e,t){return Math.max(e,Math.min(t,i))}function E(i,e,t,n,r){let s=i[e];if(s==null||s==="")return ke(t,n,r);let a=Number(s);return ke(Number.isFinite(a)?a:t,n,r)}function C(i,e){i&&(i.value=e)}function _(i){try{i?.disconnect()}catch{}}function R(i){i.forEach(e=>{e.dispose?.(),_(e.input),e.output!==e.input&&_(e.output)}),i.length=0}function ge(i){if(!i||typeof i!="object")return!1;let e=i;return typeof e.connect=="function"&&typeof e.disconnect=="function"}function Kt(i){if(!i)return null;if(typeof i=="object"&&("input"in i||"output"in i)){let e=i;if(ge(e.input)&&ge(e.output))return{input:e.input,output:e.output,dispose:typeof e.dispose=="function"?e.dispose:void 0,update:typeof e.update=="function"?e.update:void 0};throw new TypeError("effect plugin must return an AudioNode or { input, output } AudioNodes")}if(ge(i))return{input:i,output:i};throw new TypeError("effect plugin must return an AudioNode or { input, output } AudioNodes")}function ht(i,e,t){let n=i.createGain(),r=i.createGain(),s=i.createGain(),a=i.createGain();s.gain.value=1-e,a.gain.value=e,n.connect(s),s.connect(r);let o=t(n,a);return a.connect(r),{input:n,output:r,setWet:u=>{s.gain.value=1-u,a.gain.value=u},dispose:()=>{[n,r,s,a,...o].forEach(_)}}}function jt(i,e,t){let n=Math.max(1,Math.floor(i.sampleRate*e)),r=i.createBuffer(2,n,i.sampleRate);for(let s=0;s<r.numberOfChannels;s++){let a=r.getChannelData(s);for(let o=0;o<n;o++){let u=o/n;a[o]=(Math.random()*2-1)*Math.pow(1-u,t)}}return r}function qt(i,e){switch(e.type){case"gain":{let t=i.createGain(),n=r=>(t.gain.value=E(r,"gain",1,0,4),!0);return n(e),{input:t,output:t,update:n}}case"filter":{let t=i.createBiquadFilter(),n=r=>(t.type=String(r.filter_type||"lowpass"),t.frequency.value=E(r,"frequency",1200,20,2e4),t.Q.value=E(r,"q",1,1e-4,100),!0);return n(e),{input:t,output:t,update:n}}case"compressor":{let t=i.createDynamicsCompressor(),n=r=>(C(t.threshold,E(r,"threshold",-24,-100,0)),C(t.knee,E(r,"knee",30,0,40)),C(t.ratio,E(r,"ratio",12,1,20)),C(t.attack,E(r,"attack",.003,0,1)),C(t.release,E(r,"release",.25,0,1)),!0);return n(e),{input:t,output:t,update:n}}case"limiter":{let t=i.createDynamicsCompressor();C(t.knee,0),C(t.ratio,20),C(t.attack,.001);let n=r=>(C(t.threshold,E(r,"threshold",-1,-100,0)),C(t.release,E(r,"release",.05,0,1)),!0);return n(e),{input:t,output:t,update:n}}case"delay":{let t=i.createDelay(5),n=i.createGain(),r=ht(i,E(e,"wet",.35,0,1),(a,o)=>(a.connect(t),t.connect(n),n.connect(t),t.connect(o),[t,n])),s=a=>(t.delayTime.value=E(a,"time",.25,0,5),n.gain.value=E(a,"feedback",.25,0,.95),r.setWet(E(a,"wet",.35,0,1)),!0);return s(e),{...r,update:s}}case"reverb":{let t=i.createConvolver(),n=E(e,"seconds",1.5,.01,10),r=E(e,"decay",2,.01,12);t.buffer=jt(i,n,r);let s=ht(i,E(e,"wet",.25,0,1),(o,u)=>(o.connect(t),t.connect(u),[t]));return{...s,update:o=>E(o,"seconds",1.5,.01,10)!==n||E(o,"decay",2,.01,12)!==r?!1:(s.setWet(E(o,"wet",.25,0,1)),!0)}}default:return null}}var Wt=Object.fromEntries(w.map(i=>[i,qt]));function Q(){let i=globalThis,e=i.__nbplayPlugins&&typeof i.__nbplayPlugins=="object"?i.__nbplayPlugins:{},t=Object.create(null);return Object.entries(e).forEach(([n,r])=>{typeof r=="function"&&(t[n]=r)}),Object.assign(t,Wt),t}function ye(i,e=[]){let t=Q();return e.map(n=>{try{let r=Object.prototype.hasOwnProperty.call(t,n.type)?t[n.type]:void 0;return Kt(r?.(i,n))}catch(r){return console.warn("nbplay mixer effect plugin failed",n.type,r),null}}).filter(n=>n!==null)}function ve(i,e,t){let n=i;e.forEach(r=>{n.connect(r.input),n=r.output}),n.connect(t)}function ft(i){return i==="filter"?{type:i,filter_type:"lowpass",frequency:1200,q:1}:i==="compressor"?{type:i,threshold:-24,knee:30,ratio:12,attack:.003,release:.25}:i==="limiter"?{type:i,threshold:-1,release:.05}:i==="delay"?{type:i,time:.25,feedback:.25,wet:.35}:i==="reverb"?{type:i,seconds:1.5,decay:2,wet:.25}:i==="gain"?{type:i,gain:1}:{type:i}}function mt(i){return i.enabled!==!1}function $e(i=[]){return i.filter(mt).map(e=>({...e}))}function bt(i){let{enabled:e,...t}=i;return mt(i)?{...t,enabled:!1}:t}function Ee(i,e){return e.length?e[e.length-1].output:i}function xe(i,e,t){if(i.length!==t.length||e.length!==t.length)return!1;for(let n=0;n<t.length;n++)if(e[n].type!==t[n].type)return!1;for(let n=0;n<t.length;n++){if(JSON.stringify(e[n])===JSON.stringify(t[n]))continue;let r=i[n].update;if(!r||!r(t[n]))return!1}return!0}function Ae(i,e){if(!i)return{peak:0,rms:0};i.getFloatTimeDomainData(e);let t=0,n=0;for(let r=0;r<e.length;r++){let s=Math.abs(e[r]);s>t&&(t=s),n+=e[r]*e[r]}return{peak:t,rms:Math.sqrt(n/Math.max(1,e.length))}}function gt(){let i=null,e=null,t=[],n=[],r=null,s=!1,a=[],o=[],u=new Float32Array(256);function h(l){R(l.effects),l.input.disconnect(),l.gain.disconnect(),_(l.analyser)}function m(){if(!i?.createAnalyser)return null;let l=i.createAnalyser();return l.fftSize=256,l.smoothingTimeConstant=.6,l}return{init(l){if(i)return;let d=be(l);i=d?pt(d):q(),i&&(e=i.createGain(),e.connect(i.destination),r=m())},syncChannels(l,d,b=[],x=[]){if(!i||!e)return;for(;a.length<l.length;){let c=i.createGain(),$=i.createStereoPanner();c.connect($),$.connect(e),a.push({gain:c,pan:$,effects:[],descriptors:[],analyser:m(),sends:[]});let v=a[a.length-1];v.analyser&&$.connect(v.analyser)}for(;a.length>l.length;){let c=a.pop();R(c.effects),c.gain.disconnect(),c.pan.disconnect(),c.sends.forEach($=>$.disconnect()),_(c.analyser)}for(;o.length<x.length;){let c=i.createGain(),$=i.createGain();c.connect($),$.connect(e);let v={input:c,gain:$,effects:[],descriptors:[],analyser:m()};v.analyser&&$.connect(v.analyser),o.push(v)}for(;o.length>x.length;)h(o.pop());o.forEach((c,$)=>{let v=$e(x[$]?.effects);JSON.stringify(c.descriptors)!==JSON.stringify(v)&&(xe(c.effects,c.descriptors,v)||(_(c.input),R(c.effects),c.effects=ye(i,v),ve(c.input,c.effects,c.gain)),c.descriptors=v),c.gain.gain.value=x[$].gain}),a.forEach((c,$)=>{let v=$e(l[$]?.effects);if(c.descriptors.length===v.length&&JSON.stringify(c.descriptors)===JSON.stringify(v))return;if(xe(c.effects,c.descriptors,v)){c.descriptors=v;return}_(c.pan),R(c.effects),c.effects=ye(i,v),c.descriptors=v,ve(c.pan,c.effects,e);let k=Ee(c.pan,c.effects);c.analyser&&k.connect(c.analyser),c.sends.forEach(te=>k.connect(te))}),a.forEach((c,$)=>{for(;c.sends.length>o.length;)c.sends.pop().disconnect();for(;c.sends.length<o.length;){let k=i.createGain();k.gain.value=0,Ee(c.pan,c.effects).connect(k),k.connect(o[c.sends.length].input),c.sends.push(k)}let v=l[$]?.sends||[];c.sends.forEach((k,te)=>{k.gain.value=ke(Number(v[te])||0,0,1)})});let O=$e(b);(!s||JSON.stringify(n)!==JSON.stringify(O))&&(s&&xe(t,n,O)?n=O:(_(e),R(t),t=ye(i,O),n=O,s=!0,ve(e,t,i.destination),r&&Ee(e,t).connect(r)));let _t=l.some(c=>c.solo);l.forEach((c,$)=>{let v=a[$],k=c.gain;(c.mute||_t&&!c.solo)&&(k=0),v.gain.gain.value=k,v.pan.pan.value=c.pan}),e.gain.value=d},levels(){return i?{channels:a.map(l=>Ae(l.analyser,u)),returns:o.map(l=>Ae(l.analyser,u)),master:Ae(r,u)}:null},register(l){if(!i||!e)return;let d=dt(l);d.audioCtx=i,d.masterGain=e,d.channels=a,d.returns=o,Object.defineProperty(d,"plugins",{configurable:!0,enumerable:!0,get:Q}),document.dispatchEvent(new CustomEvent("nbplay-bus-ready",{detail:{sessionId:l}}))},destroy(l){let d=be(l);if(d&&(delete d.audioCtx,delete d.masterGain,delete d.channels,delete d.returns,delete d.plugins,Object.keys(d).length===0)){let b=globalThis;delete b.__nbplay[l]}a.forEach(b=>{R(b.effects),b.gain.disconnect(),b.pan.disconnect(),b.sends.forEach(x=>x.disconnect()),_(b.analyser)}),a.length=0,o.forEach(h),o.length=0,R(t),n=[],s=!1,_(r),r=null,e&&e.disconnect(),i&&i.state!=="closed"&&i.close(),i=null,e=null,t=[]}}}var g=class extends M{constructor(){super(),this.theme=""}createRenderRoot(){return this}emit(e,t){this.emitDetail(e,{value:t})}emitDetail(e,t){this.dispatchEvent(new CustomEvent(e,{detail:t,bubbles:!0,composed:!0}))}};g.createProperty("theme",{type:String,attribute:"data-nbplay-theme",reflect:!0,converter:{fromAttribute:i=>i??"",toAttribute:i=>i||null}});function y(i,e){customElements.get(i)||customElements.define(i,e)}function A(i,e,t){return Math.min(t,Math.max(e,i))}function ee(i,e){if(!(e>0))return i;let t=Math.max(0,Math.ceil(-Math.log10(e)));return Number((Math.round(i/e)*e).toFixed(t))}var Ce=class extends g{static properties={title:{type:String},badge:{type:String},status:{type:String}};actions=null;constructor(){super(),this.title="nbplay",this.badge="",this.status=""}connectedCallback(){this.actions===null&&(this.actions=Array.from(this.childNodes)),super.connectedCallback()}render(){let e=this.actions??[];return p`<h3 class="nbplay-header-title">${this.title}</h3>
      ${this.badge?p`<span class="nbplay-header-badge">${this.badge}</span>`:f}
      ${this.status?p`<span class="nbplay-header-status">${this.status}</span>`:f}
      <div class="nbplay-header-actions">${e}</div>`}};y("nbplay-header",Ce);var yt=270,j=-135,vt=150;function _e(i,e){let t=(i-90)*Math.PI/180;return[50+e*Math.cos(t),50+e*Math.sin(t)]}function $t(i,e,t){let[n,r]=_e(i,t),[s,a]=_e(e,t),o=e-i>180?1:0;return`M ${n} ${r} A ${t} ${t} 0 ${o} 1 ${s} ${a}`}var Se=class extends g{static properties={value:{type:Number},min:{type:Number},max:{type:Number},step:{type:Number},defaultValue:{type:Number,attribute:"default-value"},disabled:{type:Boolean,reflect:!0},dragging:{type:Boolean,reflect:!0}};startY=0;startValue=0;constructor(){super(),this.value=0,this.min=0,this.max=1,this.step=.01,this.defaultValue=null,this.disabled=!1,this.dragging=!1}connectedCallback(){super.connectedCallback(),this.hasAttribute("tabindex")||(this.tabIndex=0),this.setAttribute("role","slider"),this.addEventListener("pointerdown",this.onPointerDown),this.addEventListener("pointermove",this.onPointerMove),this.addEventListener("pointerup",this.onPointerUp),this.addEventListener("lostpointercapture",this.onPointerUp),this.addEventListener("wheel",this.onWheel,{passive:!1}),this.addEventListener("keydown",this.onKeydown),this.addEventListener("dblclick",this.onDblclick)}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener("pointerdown",this.onPointerDown),this.removeEventListener("pointermove",this.onPointerMove),this.removeEventListener("pointerup",this.onPointerUp),this.removeEventListener("lostpointercapture",this.onPointerUp),this.removeEventListener("wheel",this.onWheel),this.removeEventListener("keydown",this.onKeydown),this.removeEventListener("dblclick",this.onDblclick)}updated(){this.setAttribute("aria-valuemin",String(this.min)),this.setAttribute("aria-valuemax",String(this.max)),this.setAttribute("aria-valuenow",String(this.value)),this.setAttribute("aria-disabled",String(this.disabled))}fraction(){return this.max>this.min?A((this.value-this.min)/(this.max-this.min),0,1):0}render(){let e=j+this.fraction()*yt,[t,n]=_e(e,30);return p`<svg
      class="nbplay-dial-svg"
      viewBox="0 0 100 100"
      aria-hidden="true"
    >
      ${K`<path class="nbplay-dial-track" d=${$t(j,j+yt,40)} />`}
      ${K`<path class="nbplay-dial-arc" d=${$t(j,Math.max(e,j+.01),40)} />`}
      ${K`<circle class="nbplay-dial-cap" cx="50" cy="50" r="30" />`}
      ${K`<line class="nbplay-dial-indicator" x1="50" y1="50" x2=${t} y2=${n} />`}
    </svg>`}set(e,t){let n=A(ee(e,this.step),this.min,this.max);n!==this.value&&(this.value=n,this.emit("input",n)),t&&this.emit("change",this.value)}reset(){this.disabled||this.defaultValue===null||(this.dragging=!1,this.set(this.defaultValue,!0))}onDblclick=()=>this.reset();onPointerDown=e=>{this.disabled||e.button!==0||(e.preventDefault(),this.focus(),this.setPointerCapture(e.pointerId),this.dragging=!0,this.startY=e.clientY,this.startValue=this.value)};onPointerMove=e=>{if(!this.dragging)return;let t=e.shiftKey?vt*4:vt,n=(this.startY-e.clientY)/t*(this.max-this.min);this.set(this.startValue+n,!1)};onPointerUp=()=>{this.dragging&&(this.dragging=!1,this.emit("change",this.value))};onWheel=e=>{if(this.disabled)return;e.preventDefault();let t=e.deltaY!==0?e.deltaY:e.deltaX;t!==0&&this.set(this.value+(t<0?this.step:-this.step),!0)};onKeydown=e=>{if(this.disabled)return;let t=this.step*10,n={ArrowUp:this.step,ArrowRight:this.step,ArrowDown:-this.step,ArrowLeft:-this.step,PageUp:t,PageDown:-t},r;e.key in n?r=this.value+n[e.key]:e.key==="Home"?r=this.min:e.key==="End"&&(r=this.max),r!==void 0&&(e.preventDefault(),this.set(r,!0))}};y("nbplay-dial",Se);var we=class extends g{static properties={value:{type:Number},min:{type:Number},max:{type:Number},step:{type:Number},defaultValue:{type:Number,attribute:"default-value"},orientation:{type:String,reflect:!0},scale:{type:String},disabled:{type:Boolean,reflect:!0},dragging:{type:Boolean,reflect:!0}};internal=!1;constructor(){super(),this.value=0,this.min=0,this.max=1,this.step=.01,this.defaultValue=null,this.orientation="horizontal",this.scale="linear",this.disabled=!1,this.dragging=!1}willUpdate(e){e.has("value")&&this.dragging&&!this.internal&&(this.value=e.get("value"))}toPos(e){if(this.scale!=="log")return e;let t=Math.log(this.min),n=Math.log(this.max);return(Math.log(Math.max(e,this.min))-t)/(n-t)}fromPos(e){if(this.scale!=="log")return e;let t=Math.log(this.min),n=Math.log(this.max);return Math.exp(t+e*(n-t))}render(){let e=this.scale==="log";return p`<input
      type="range"
      class="nbplay-slider-input"
      min=${e?0:this.min}
      max=${e?1:this.max}
      step=${e?.001:this.step}
      .value=${String(this.toPos(this.value))}
      ?disabled=${this.disabled}
      aria-valuemin=${this.min}
      aria-valuemax=${this.max}
      aria-valuenow=${this.value}
      @input=${this.onInput}
      @change=${this.onChange}
      @pointerdown=${this.startDrag}
      @pointerup=${this.endDrag}
      @lostpointercapture=${this.endDrag}
      @dblclick=${this.reset}
    />`}readValue(e){let t=parseFloat(e.target.value);return A(ee(this.fromPos(t),this.step),this.min,this.max)}onInput(e){e.stopPropagation(),this.internal=!0,this.value=this.readValue(e),this.internal=!1,this.emit("input",this.value)}onChange(e){e.stopPropagation(),this.endDrag(),this.emit("change",this.value)}reset(){if(this.disabled||this.defaultValue===null)return;this.endDrag();let e=A(this.defaultValue,this.min,this.max);e!==this.value&&(this.value=e,this.emit("input",e)),this.emit("change",this.value)}startDrag(){this.disabled||(this.dragging=!0)}endDrag(){this.dragging=!1}};y("nbplay-slider",we);var Yt=["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"];function Jt(i,e=60){let t=Number(i);return Number.isFinite(t)?Math.max(0,Math.min(127,Math.round(t))):e}function Ne(i){let e=Jt(i),t=Math.floor(e/12)-1;return Yt[e%12]+t}function Et(i){let e=i.trim(),t=Number.parseInt(e,10);if(String(t)===e&&t>=0&&t<=127)return t;let n=e.match(/^([A-Ga-g])([#b]?)\s*(-?\d+)$/);if(!n)return null;let s={c:0,d:2,e:4,f:5,g:7,a:9,b:11}[n[1].toLowerCase()];if(s===void 0)return null;let a=s;n[2]==="#"&&(a+=1),n[2]==="b"&&(a-=1);let u=(Number.parseInt(n[3],10)+1)*12+a;return u>=0&&u<=127?u:null}function xt(i,e,t=2,n=""){switch(e){case"int":return`${Math.round(i)}${n}`;case"db":return ne(i);case"pan":return Ve(i);case"hz":return i>=1e3?(i/1e3).toFixed(2)+" kHz":i.toFixed(1)+" Hz";case"bpm":return`${Math.round(i)} BPM`;case"seconds":return i<.01?(i*1e3).toFixed(1)+" ms":i<1?(i*1e3).toFixed(0)+" ms":i.toFixed(2)+" s";case"percent":return(i*100).toFixed(0)+"%";case"note":return Ne(i);default:return`${i.toFixed(t)}${n}`}}function At(i,e,t=2){switch(e){case"int":case"bpm":return String(Math.round(i));case"db":return ne(i).replace(" dB","");case"pan":return String(Math.round(i*100)/100);case"percent":return(i*100).toFixed(0);case"note":return Ne(i);case"float":return i.toFixed(t);default:return String(i)}}function kt(i,e){let t=i.trim();if(!t)return null;switch(e){case"db":return He(t);case"note":return Et(t);case"int":case"bpm":{let n=parseInt(t,10);return Number.isNaN(n)?null:n}case"percent":{let n=parseFloat(t);return Number.isFinite(n)?n>1?n/100:n:null}case"hz":{let n=parseFloat(t);return Number.isFinite(n)?/k/i.test(t)?n*1e3:n:null}default:{let n=parseFloat(t);return Number.isFinite(n)?n:null}}}var Ct=i=>i.stopPropagation(),Me=class extends g{static properties={value:{type:Number},kind:{type:String},min:{type:Number},max:{type:Number},precision:{type:Number},unit:{type:String},editable:{type:Boolean},editing:{type:Boolean,reflect:!0}};constructor(){super(),this.value=0,this.kind="float",this.min=-1/0,this.max=1/0,this.precision=2,this.unit="",this.editable=!0,this.editing=!1}get text(){return xt(this.value,this.kind,this.precision,this.unit)}render(){return this.editing?p`<input
        type="text"
        class="nbplay-value-input"
        .value=${At(this.value,this.kind,this.precision)}
        @keydown=${this.onKeydown}
        @blur=${this.commit}
        @input=${Ct}
        @change=${Ct}
      />`:p`<span
      class="nbplay-value-text"
      title=${this.editable?"Double-click to edit":f}
      @dblclick=${this.startEdit}
      >${this.text}</span
    >`}startEdit(){!this.editable||this.editing||(this.editing=!0,this.updateComplete.then(()=>{let e=this.querySelector("input");e?.focus(),e?.select()}))}onKeydown(e){e.key==="Enter"?(e.preventDefault(),this.commit()):e.key==="Escape"&&(this.editing=!1)}commit(){if(!this.editing)return;let e=this.querySelector("input");if(this.editing=!1,!e)return;let t=kt(e.value,this.kind);if(t===null)return;let n=A(t,this.min,this.max);n!==this.value&&(this.value=n,this.emit("change",n))}};y("nbplay-value",Me);var Pe=class extends g{static properties={label:{type:String},value:{type:Number},min:{type:Number},max:{type:Number},step:{type:Number},defaultValue:{type:Number,attribute:"default-value"},scale:{type:String},kind:{type:String},control:{type:String,reflect:!0},precision:{type:Number},unit:{type:String},editable:{type:Boolean},disabled:{type:Boolean,reflect:!0}};constructor(){super(),this.label="",this.value=0,this.min=0,this.max=1,this.step=.01,this.defaultValue=null,this.scale="linear",this.kind="float",this.control="slider",this.precision=2,this.unit="",this.editable=!0,this.disabled=!1}render(){let e=this.control==="dial"?p`<nbplay-dial
            .value=${this.value}
            .min=${this.min}
            .max=${this.max}
            .step=${this.step}
            .defaultValue=${this.defaultValue}
            .disabled=${this.disabled}
            @input=${this.onInput}
            @change=${this.onChange}
          ></nbplay-dial>`:p`<nbplay-slider
            .value=${this.value}
            .min=${this.min}
            .max=${this.max}
            .step=${this.step}
            .defaultValue=${this.defaultValue}
            .scale=${this.scale}
            .disabled=${this.disabled}
            @input=${this.onInput}
            @change=${this.onChange}
          ></nbplay-slider>`;return p`<span class="nbplay-param-label">${this.label}</span>
      ${e}
      <nbplay-value
        .value=${this.value}
        .kind=${this.kind}
        .min=${this.min}
        .max=${this.max}
        .precision=${this.precision}
        .unit=${this.unit}
        .editable=${this.editable&&!this.disabled}
        @change=${this.onChange}
      ></nbplay-value>`}onInput(e){e.stopPropagation(),this.value=e.detail.value,this.emit("input",this.value)}onChange(e){e.stopPropagation(),this.value=e.detail.value,this.emit("change",this.value)}};y("nbplay-param",Pe);var De=class extends g{static properties={effect:{attribute:!1},specs:{attribute:!1},disabled:{type:Boolean,reflect:!0}};constructor(){super(),this.effect={type:"gain"},this.specs=null,this.disabled=!1}render(){let e=this.specs??me(this.effect);return e.length?p`${e.map(t=>this.renderRow(t))}`:p`<span class="nbplay-effect-editor-none">No parameters</span>`}renderRow(e){let t=this.effect[e.key],n=s=>s.stopPropagation();if(e.kind==="select")return p`<label class="nbplay-effect-editor-row">
        <span>${e.label}</span>
        <select
          data-key=${e.key}
          ?disabled=${this.disabled}
          @input=${n}
          @change=${s=>{s.stopPropagation(),this.commit(e.key,s.target.value)}}
        >
          ${(e.options??[]).map(s=>p`<option value=${s} ?selected=${s===t}>
                ${s}
              </option>`)}
        </select>
      </label>`;if(e.kind==="bool")return p`<label class="nbplay-effect-editor-row">
        <span>${e.label}</span>
        <input
          type="checkbox"
          data-key=${e.key}
          .checked=${!!t}
          ?disabled=${this.disabled}
          @input=${n}
          @change=${s=>{s.stopPropagation(),this.commit(e.key,s.target.checked)}}
        />
      </label>`;if(e.kind==="text")return p`<label class="nbplay-effect-editor-row">
        <span>${e.label}</span>
        <input
          type="text"
          data-key=${e.key}
          .value=${String(t??"")}
          ?disabled=${this.disabled}
          @input=${n}
          @change=${s=>{s.stopPropagation(),this.commit(e.key,s.target.value)}}
        />
      </label>`;let r=Number(t);return e.min!==void 0&&e.max!==void 0?p`<nbplay-param
        class="nbplay-effect-editor-param"
        control="dial"
        data-key=${e.key}
        .label=${e.label}
        .value=${Number.isFinite(r)?r:e.min}
        .min=${e.min}
        .max=${e.max}
        .step=${e.step??.01}
        .defaultValue=${e.default??null}
        .precision=${Zt(e.step??.01)}
        .disabled=${this.disabled}
        @input=${n}
        @change=${s=>{s.stopPropagation(),this.commit(e.key,s.detail.value)}}
      ></nbplay-param>`:p`<label class="nbplay-effect-editor-row">
      <span>${e.label}</span>
      <input
        type="number"
        step="any"
        data-key=${e.key}
        .value=${String(Number.isFinite(r)?r:0)}
        ?disabled=${this.disabled}
        @input=${n}
        @change=${s=>{s.stopPropagation();let a=parseFloat(s.target.value);Number.isFinite(a)&&this.commit(e.key,a)}}
      />
    </label>`}commit(e,t){let n=(this.specs??me(this.effect)).find(r=>r.key===e);n?.kind==="number"&&typeof t=="number"&&(t=A(t,n.min??-1/0,n.max??1/0)),this.effect={...this.effect,[e]:t},this.emitDetail("change",{key:e,value:t})}};function Zt(i){return Math.max(0,Math.ceil(-Math.log10(i)))}y("nbplay-effect-editor",De);var Te=class extends g{static properties={effects:{attribute:!1},types:{attribute:!1},editing:{type:Number},disabled:{type:Boolean,reflect:!0}};constructor(){super(),this.effects=[],this.types=w,this.editing=-1,this.disabled=!1}render(){let e=t=>t.stopPropagation();return p`<div class="nbplay-effect-rack-add">
        <select
          class="nbplay-effect-rack-type"
          title="Effect type"
          ?disabled=${this.disabled}
          @input=${e}
          @change=${e}
        >
          ${this.types.map(t=>p`<option value=${t}>${t}</option>`)}
        </select>
        <button
          type="button"
          class="nbplay-effect-rack-add-btn"
          title="Add effect"
          ?disabled=${this.disabled}
          @click=${this.add}
        >
          +
        </button>
      </div>
      <div class="nbplay-effect-rack-list">
        ${this.effects.map((t,n)=>this.renderItem(t,n))}
      </div>`}renderItem(e,t){let n=ut(e),r=this.editing===t;return p`<div class="nbplay-effect-rack-item" data-index=${t}>
      <div class="nbplay-effect-rack-chip-row">
        <button
          type="button"
          class="nbplay-effect-rack-chip ${n?"":"bypassed"}"
          title=${n?"Bypass effect":"Enable effect"}
          ?disabled=${this.disabled}
          @click=${()=>this.emitDetail("change",{index:t,field:"enabled",value:!n})}
        >
          ${ct(e)}
        </button>
        <button
          type="button"
          class="nbplay-effect-rack-edit ${r?"active":""}"
          title="Edit effect"
          ?disabled=${this.disabled}
          @click=${()=>{this.editing=r?-1:t,this.emitDetail("nbplay-effect-editing",{index:this.editing})}}
        >
          ✎
        </button>
        <button
          type="button"
          class="nbplay-effect-rack-remove"
          title="Remove effect"
          ?disabled=${this.disabled}
          @click=${()=>this.emitDetail("nbplay-effect-remove",{index:t})}
        >
          ×
        </button>
      </div>
      ${r?p`<nbplay-effect-editor
              .effect=${e}
              .disabled=${this.disabled}
              @input=${s=>s.stopPropagation()}
              @change=${s=>{s.stopPropagation();let{key:a,value:o}=s.detail;this.emitDetail("change",{index:t,field:a,value:o})}}
            ></nbplay-effect-editor>`:f}
    </div>`}add(){let t=this.querySelector(".nbplay-effect-rack-type")?.value||this.types[0];t&&this.emitDetail("nbplay-effect-add",{type:t})}};y("nbplay-effect-rack",Te);var Be=class extends g{static properties={level:{type:Number},rms:{type:Number},orientation:{type:String,reflect:!0},floorDb:{type:Number,attribute:"floor-db"},hotThreshold:{type:Number,attribute:"hot-threshold"},hot:{type:Boolean,reflect:!0}};constructor(){super(),this.level=0,this.rms=0,this.orientation="vertical",this.floorDb=-60,this.hotThreshold=.99,this.hot=!1}percent(e){if(!(e>0))return 0;let t=Ie(e);return A((t-this.floorDb)/(0-this.floorDb),0,1)*100}willUpdate(){this.hot=this.level>=this.hotThreshold}render(){return p`<div class="nbplay-meter-track">
      <div
        class="nbplay-meter-rms"
        style="--nbplay-meter-fill: ${this.percent(this.rms)}%"
      ></div>
      <div
        class="nbplay-meter-fill"
        style="--nbplay-meter-fill: ${this.percent(this.level)}%"
      ></div>
    </div>`}};y("nbplay-meter",Be);var Re=class extends g{static properties={value:{type:Number},min:{type:Number},max:{type:Number},step:{type:Number},defaultValue:{type:Number,attribute:"default-value"},level:{type:Number},rms:{type:Number},label:{type:String},editable:{type:Boolean},disabled:{type:Boolean,reflect:!0}};constructor(){super(),this.value=.8,this.min=0,this.max=2,this.step=.01,this.defaultValue=1,this.level=0,this.rms=0,this.label="",this.editable=!0,this.disabled=!1}render(){return p`${this.label?p`<span class="nbplay-fader-label">${this.label}</span>`:f}
      <div class="nbplay-fader-body">
        <nbplay-meter .level=${this.level} .rms=${this.rms}></nbplay-meter>
        <nbplay-slider
          orientation="vertical"
          .value=${this.value}
          .min=${this.min}
          .max=${this.max}
          .step=${this.step}
          .defaultValue=${this.defaultValue}
          .disabled=${this.disabled}
          @input=${this.onInput}
          @change=${this.onChange}
        ></nbplay-slider>
      </div>
      <nbplay-value
        kind="db"
        .value=${this.value}
        .min=${this.min}
        .max=${this.max}
        .editable=${this.editable&&!this.disabled}
        @change=${this.onChange}
      ></nbplay-value>`}onInput(e){e.stopPropagation(),this.value=e.detail.value,this.emit("input",this.value)}onChange(e){e.stopPropagation(),this.value=e.detail.value,this.emit("change",this.value)}};y("nbplay-fader",Re);var Le=class extends g{static properties={active:{type:Boolean,reflect:!0},variant:{type:String,reflect:!0},label:{type:String},title:{type:String},disabled:{type:Boolean,reflect:!0}};constructor(){super(),this.active=!1,this.variant="default",this.label="",this.title="",this.disabled=!1}render(){return p`<button
      type="button"
      class="nbplay-toggle-button"
      aria-pressed=${String(this.active)}
      title=${this.title||f}
      ?disabled=${this.disabled}
      @click=${this.toggle}
    >
      ${this.label}
    </button>`}toggle(){this.disabled||(this.active=!this.active,this.emit("change",this.active))}};y("nbplay-toggle",Le);var Fe=class extends g{static properties={kind:{type:String,reflect:!0},name:{type:String},gain:{type:Number},pan:{type:Number},mute:{type:Boolean},solo:{type:Boolean},sends:{attribute:!1},sendNames:{attribute:!1},effects:{attribute:!1},effectTypes:{attribute:!1},level:{type:Number},rms:{type:Number},editable:{type:Boolean},disabled:{type:Boolean,reflect:!0}};constructor(){super(),this.kind="channel",this.name="",this.gain=.8,this.pan=0,this.mute=!1,this.solo=!1,this.sends=[],this.sendNames=[],this.effects=[],this.effectTypes=w,this.level=0,this.rms=0,this.editable=!0,this.disabled=!1}render(){let e=this.kind==="channel",t=n=>n.stopPropagation();return p`<div class="nbplay-strip-name" title=${this.name}>
        ${this.name}
      </div>
      <nbplay-fader
        .value=${this.gain}
        .level=${this.level}
        .rms=${this.rms}
        .editable=${this.editable}
        .disabled=${this.disabled}
        @input=${n=>this.forward(n,"input","gain")}
        @change=${n=>this.forward(n,"change","gain")}
      ></nbplay-fader>
      ${e?p`<div class="nbplay-strip-pan">
                <nbplay-value
                  kind="pan"
                  .value=${this.pan}
                  .min=${-1}
                  .max=${1}
                  .editable=${this.editable&&!this.disabled}
                  @input=${t}
                  @change=${n=>this.forward(n,"change","pan")}
                ></nbplay-value>
                <nbplay-slider
                  .value=${this.pan}
                  .min=${-1}
                  .max=${1}
                  .step=${.01}
                  .defaultValue=${0}
                  .disabled=${this.disabled}
                  @input=${n=>this.forward(n,"input","pan")}
                  @change=${n=>this.forward(n,"change","pan")}
                ></nbplay-slider>
              </div>
              <div class="nbplay-strip-buttons">
                <nbplay-toggle
                  variant="mute"
                  label="M"
                  title="Mute"
                  .active=${this.mute}
                  .disabled=${this.disabled}
                  @change=${n=>this.forward(n,"change","mute")}
                ></nbplay-toggle>
                <nbplay-toggle
                  variant="solo"
                  label="S"
                  title="Solo"
                  .active=${this.solo}
                  .disabled=${this.disabled}
                  @change=${n=>this.forward(n,"change","solo")}
                ></nbplay-toggle>
              </div>
              ${this.sendNames.length?p`<div class="nbplay-strip-sends">
                      ${this.sendNames.map((n,r)=>p`<label
                            class="nbplay-strip-send"
                            title="Send to ${n}"
                          >
                            <span>${n}</span>
                            <nbplay-slider
                              .value=${this.sends[r]??0}
                              .min=${0}
                              .max=${1}
                              .step=${.01}
                              .defaultValue=${0}
                              .disabled=${this.disabled}
                              @input=${s=>this.forwardSend(s,"input",r)}
                              @change=${s=>this.forwardSend(s,"change",r)}
                            ></nbplay-slider>
                          </label>`)}
                    </div>`:f}`:f}
      <nbplay-effect-rack
        .effects=${this.effects}
        .types=${this.effectTypes}
        .disabled=${this.disabled}
        @input=${t}
        @change=${n=>{n.stopPropagation();let{index:r,field:s,value:a}=n.detail;this.emitDetail("change",{field:"effect",index:r,key:s,value:a})}}
        @nbplay-effect-editing=${n=>{this.classList.toggle("editing",n.detail.index>=0)}}
      ></nbplay-effect-rack>
      ${this.kind==="master"?f:p`<button
              type="button"
              class="nbplay-strip-remove"
              title=${e?"Remove channel":"Remove return bus"}
              ?disabled=${this.disabled}
              @click=${()=>this.emitDetail("nbplay-remove",{})}
            >
              ×
            </button>`}`}forward(e,t,n){e.stopPropagation();let r=e.detail.value;this[n]=r,this.emitDetail(t,{field:n,value:r})}forwardSend(e,t,n){e.stopPropagation();let r=e.detail.value,s=[...this.sends];s[n]=r,this.sends=s,this.emitDetail(t,{field:"send",index:n,value:r})}};y("nbplay-strip",Fe);var Xt=33,Oe=class extends g{static properties={channels:{attribute:!1,noAccessor:!0},returns:{attribute:!1,noAccessor:!0},masterGain:{type:Number,attribute:"master-gain",noAccessor:!0},masterEffects:{attribute:!1,noAccessor:!0},sessionId:{type:String,attribute:"session-id",reflect:!0}};graph={channels:[],returns:[],masterGain:.85,masterEffects:[]};bus=gt();busReady=!1;meterFrame=null;lastMeterMs=0;constructor(){super(),this.sessionId=""}get channels(){return this.graph.channels}set channels(e){this.setGraph("channels",e)}get returns(){return this.graph.returns}set returns(e){this.setGraph("returns",e)}get masterGain(){return this.graph.masterGain}set masterGain(e){this.setGraph("masterGain",e)}get masterEffects(){return this.graph.masterEffects}set masterEffects(e){this.setGraph("masterEffects",e)}setGraph(e,t){let n=this.graph[e];this.graph[e]=t,this.requestUpdate(e,n),this.busReady&&this.syncBus()}connectedCallback(){super.connectedCallback(),this.classList.add("nbplay-mixer"),this.tabIndex=0,this.sessionId&&(this.bus.init(this.sessionId),this.busReady=!0,this.syncBus(),this.bus.register(this.sessionId),typeof requestAnimationFrame=="function"&&(this.meterFrame=requestAnimationFrame(this.meterTick)))}disconnectedCallback(){super.disconnectedCallback(),this.meterFrame!==null&&cancelAnimationFrame(this.meterFrame),this.meterFrame=null,this.busReady=!1,this.sessionId&&this.bus.destroy(this.sessionId)}syncBus(){this.bus.syncChannels(this.channels||[],Number(this.masterGain),this.masterEffects||[],this.returns||[])}set(e){this.emitDetail("nbplay-set",{values:e})}applyLevel(e,t){if(!e)return;e.dataset.peak=t.peak.toFixed(3);let n=e.querySelector("nbplay-meter");n&&(n.level=t.peak,n.rms=t.rms)}meterTick=e=>{if(this.meterFrame=requestAnimationFrame(this.meterTick),e-this.lastMeterMs<Xt||document.hidden)return;this.lastMeterMs=e;let t=this.bus.levels();if(!t)return;let n=this.querySelectorAll('nbplay-strip[kind="channel"]');t.channels.forEach((s,a)=>this.applyLevel(n[a]||null,s));let r=this.querySelectorAll('nbplay-strip[kind="return"]');t.returns.forEach((s,a)=>this.applyLevel(r[a]||null,s)),this.applyLevel(this.querySelector('nbplay-strip[kind="master"]'),t.master)};updateChannel(e,t,n){let r=[...this.channels||[]];e>=r.length||r[e][t]!==n&&(r[e]={...r[e],[t]:n},this.channels=r,this.set({channels:r}))}updateReturn(e,t,n){let r=[...this.returns||[]];e>=r.length||r[e][t]!==n&&(r[e]={...r[e],[t]:n},this.returns=r,this.set({returns:r}))}effectsFor(e,t){return e==="master"?this.masterEffects||[]:e==="return"?this.returns?.[t]?.effects||[]:this.channels?.[t]?.effects||[]}writeEffects(e,t,n){e==="master"?(this.masterEffects=n,this.set({masterEffects:n})):e==="return"?this.updateReturn(t,"effects",n):this.updateChannel(t,"effects",n)}onStripEdit(e,t,n){n.stopPropagation();let r=n.detail;if(r.field==="effect"){let s=r.index??-1,a=this.effectsFor(e,t);r.key==="enabled"?this.writeEffects(e,t,a.map((o,u)=>u===s?bt(o):o)):r.value!==void 0&&this.writeEffects(e,t,a.map((o,u)=>u===s?{...o,[r.key]:r.value}:o));return}if(e==="master"){r.field==="gain"&&r.value!==this.masterGain&&(this.masterGain=r.value,this.set({masterGain:this.masterGain}));return}if(e==="return"){r.field==="gain"&&this.updateReturn(t,"gain",r.value);return}if(r.field==="send"){let s=this.channels?.[t],a=r.index??-1;if(!s||a<0)return;let o=Array.from({length:(this.returns||[]).length},(u,h)=>A(Number(s.sends?.[h])||0,0,1));o[a]=A(Number(r.value)||0,0,1),this.updateChannel(t,"sends",o);return}this.updateChannel(t,r.field,r.value)}onEffectAdd(e,t,n){n.stopPropagation();let r=n.detail.type;this.writeEffects(e,t,[...this.effectsFor(e,t),ft(r)])}onEffectRemove(e,t,n){n.stopPropagation();let r=n.detail.index;this.writeEffects(e,t,this.effectsFor(e,t).filter((s,a)=>a!==r))}addChannel(){let e=[...this.channels||[]];e.push({name:"Ch "+(e.length+1),gain:.8,pan:0,mute:!1,solo:!1,effects:[]}),this.channels=e,this.set({channels:e})}removeChannel(e){let t=[...this.channels||[]];t.splice(e,1),this.channels=t,this.set({channels:t})}addReturn(){let e=this.returns||[],t=[...e,{name:`Return ${e.length+1}`,gain:.8,effects:[]}],n=(this.channels||[]).map(r=>({...r,sends:[...Array.from({length:e.length},(s,a)=>A(Number(r.sends?.[a])||0,0,1)),0]}));this.returns=t,this.channels=n,this.set({returns:t,channels:n})}removeReturn(e){let t=(this.returns||[]).filter((r,s)=>s!==e),n=(this.channels||[]).map(r=>({...r,sends:(r.sends||[]).filter((s,a)=>a!==e)}));this.returns=t,this.channels=n,this.set({returns:t,channels:n})}render(){let e=this.channels||[],t=this.returns||[],n=t.map(a=>a.name),r=[...w,...Object.keys(Q()).filter(a=>!w.includes(a))],s=(a,o,u,h)=>p`<nbplay-strip
        class=${u}
        kind=${a}
        data-index=${o}
        .name=${h.name}
        .gain=${h.gain}
        .pan=${h.pan??0}
        .mute=${!!h.mute}
        .solo=${!!h.solo}
        .sends=${h.sends??[]}
        .sendNames=${a==="channel"?n:[]}
        .effects=${h.effects??[]}
        .effectTypes=${r}
        @input=${m=>this.onStripEdit(a,o,m)}
        @change=${m=>this.onStripEdit(a,o,m)}
        @nbplay-effect-add=${m=>this.onEffectAdd(a,o,m)}
        @nbplay-effect-remove=${m=>this.onEffectRemove(a,o,m)}
        @nbplay-remove=${m=>{m.stopPropagation(),a==="channel"?this.removeChannel(o):a==="return"&&this.removeReturn(o)}}
      ></nbplay-strip>`;return p`<nbplay-header badge="mixer">
        <button
          type="button"
          class="nbplay-mixer-add-btn"
          title="Add channel"
          @click=${()=>this.addChannel()}
        >
          + Channel
        </button>
        <button
          type="button"
          class="nbplay-mixer-add-return-btn"
          title="Add return bus"
          @click=${()=>this.addReturn()}
        >
          + Return
        </button>
      </nbplay-header>
      <div class="nbplay-mixer-console">
        ${e.map((a,o)=>s("channel",o,"nbplay-mixer-strip",{name:a.name,gain:a.gain,pan:a.pan,mute:a.mute,solo:a.solo,sends:t.map((u,h)=>A(Number(a.sends?.[h])||0,0,1)),effects:a.effects}))}
        ${t.map((a,o)=>s("return",o,"nbplay-mixer-strip nbplay-return-strip",{name:a.name,gain:a.gain,effects:a.effects}))}
        ${s("master",-1,"nbplay-mixer-strip nbplay-master-strip",{name:"Master",gain:Number(this.masterGain),effects:this.masterEffects})}
      </div>`}};y("nbplay-mixer",Oe);function Qt({model:i,el:e}){let t=document.createElement("nbplay-mixer");return Ge(i,e,t,{config:{theme:"theme",channels:"channels",returns:"returns",master_gain:"masterGain",master_effects:"masterEffects",session_id:"sessionId"},status:{}})}var Vi={render:Qt};export{Vi as default};
/*! Bundled license information:

@lit/reactive-element/css-tag.js:
  (**
   * @license
   * Copyright 2019 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/reactive-element.js:
lit-html/lit-html.js:
lit-element/lit-element.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/is-server.js:
  (**
   * @license
   * Copyright 2022 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
//# sourceMappingURL=mixer.js.map
