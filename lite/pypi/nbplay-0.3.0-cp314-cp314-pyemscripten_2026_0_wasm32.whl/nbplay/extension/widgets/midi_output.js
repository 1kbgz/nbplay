function S(n,u,i=5e3){let o=n,r=null,a=null,l=!1;if(!("comm"in o||"widget_manager"in o))return()=>{};function b(){return"comm"in o?o.comm!=null:o.widget_manager!=null}return r=setInterval(()=>{l||(!b()&&!a?a=setTimeout(()=>{!b()&&!l&&(l=!0,u()),a=null},i):b()&&a&&(clearTimeout(a),a=null))},2e3),()=>{r&&(clearInterval(r),r=null),a&&(clearTimeout(a),a=null)}}function P(){let n=globalThis;return(!n.__nbplay||typeof n.__nbplay!="object")&&(n.__nbplay={}),n.__nbplay}function M(n){let u=P();return u[n]||(u[n]={}),u[n]}function R(){let n=null,u=null;return{async requestAccess(){if(n)return n;if(!navigator.requestMIDIAccess)return null;try{return n=await navigator.requestMIDIAccess({sysex:!1}),n}catch{return null}},getOutputPorts(){let i=[];return n?.outputs.forEach(o=>{i.push({id:o.id,name:o.name||"(unnamed)"})}),i},connect(i){this.disconnect();let o=n?.outputs.get(i);return o?(u=o,{id:o.id,name:o.name||o.id}):null},disconnect(){u=null},send(i,o){if(!u)return!1;try{return o===void 0?u.send(i):u.send(i,o),!0}catch{return!1}}}}function D({model:n,el:u}){let i=R(),o=0,r=null,a="",l=document.createElement("div");l.className="nbplay-midi-output",l.innerHTML=`
    <div class="nbplay-midi-out-header">
      <h3>nbplay</h3>
      <span class="nbplay-badge">midi output</span>
    </div>
    <div class="nbplay-midi-out-row">
      <span class="nbplay-midi-out-label">Port</span>
      <select class="nbplay-midi-out-select">
        <option value="">Not connected</option>
      </select>
      <button class="nbplay-midi-out-refresh" title="Refresh MIDI ports">Refresh</button>
    </div>
    <div class="nbplay-midi-out-row">
      <span class="nbplay-midi-out-label">Channel</span>
      <select class="nbplay-midi-out-channel"></select>
      <label class="nbplay-midi-out-forward">
        <input type="checkbox" class="nbplay-midi-out-forward-input" /> Forward session notes
      </label>
    </div>
    <div class="nbplay-midi-out-row">
      <span class="nbplay-midi-out-label">Status</span>
      <span class="nbplay-midi-out-status">Idle</span>
      <span class="nbplay-midi-out-count">0 sent</span>
    </div>
  `,u.appendChild(l);let p=l.querySelector(".nbplay-midi-out-select"),b=l.querySelector(".nbplay-midi-out-refresh"),v=l.querySelector(".nbplay-midi-out-channel"),x=l.querySelector(".nbplay-midi-out-forward-input"),B=l.querySelector(".nbplay-midi-out-status"),L=l.querySelector(".nbplay-midi-out-count");for(let e=0;e<16;e++){let t=document.createElement("option");t.value=String(e),t.textContent=String(e+1),v.appendChild(t)}function y(){let e=Number(n.get("channel"));return Number.isFinite(e)?Math.max(0,Math.min(15,Math.round(e))):0}function d(e,t){let s=Number(e);return Number.isFinite(s)?Math.max(0,Math.min(127,Math.round(s))):t}function c(e,t){i.send(e,t)&&(o+=1,L.textContent=`${o} sent`)}function T(e){let t=r?.audioCtx;if(t)return performance.now()+Math.max(0,e-t.currentTime)*1e3}function g(e){if(!n.get("forward_notes"))return;let t=y(),s=d(e.note,60);if(e.type==="off"){c([128|t,s,0]);return}let m=Math.max(1,d(e.velocity,100));if(e.at===void 0){c([144|t,s,m]);return}let k=T(e.at);if(c([144|t,s,m],k),e.duration!==void 0){let I=k===void 0?void 0:k+Math.max(0,e.duration)*1e3;c([128|t,s,0],I)}}function h(e){g(e.detail)}function w(){r?.noteListeners&&(r.noteListeners=r.noteListeners.filter(e=>e!==g)),document.removeEventListener("nbplay-note",h),r=null,a=n.get("session_id")||"",a?(r=M(a),r.noteListeners||(r.noteListeners=[]),r.noteListeners.push(g)):document.addEventListener("nbplay-note",h)}function _(){let e=n.get("send_request");if(!e||!e.kind)return;let t=y();e.kind==="note_on"?c([144|t,d(e.note,60),Math.max(1,d(e.velocity,100))]):e.kind==="note_off"?c([128|t,d(e.note,60),0]):e.kind==="control_change"?c([176|t,d(e.controller,0),d(e.value,0)]):e.kind==="raw"&&Array.isArray(e.data)&&c(e.data.map(s=>Math.max(0,Math.min(255,Math.round(Number(s)||0)))))}function C(){c([176|y(),123,0])}function f(){let e=!!n.get("midi_port");B.textContent=e?"Connected":"Idle",B.classList.toggle("connected",e),v.value=String(y()),x.checked=!!n.get("forward_notes")}async function E(){let e=await i.requestAccess();if(p.innerHTML='<option value="">Not connected</option>',e){let t=i.getOutputPorts();n.set("available_midi_ports",t.map(s=>s.name)),n.save_changes(),t.forEach(s=>{let m=document.createElement("option");m.value=s.id,m.textContent=s.name,p.appendChild(m)})}f()}p.addEventListener("change",()=>{C();let e=p.value,t=e?i.connect(e):null;t||i.disconnect(),n.set("midi_port",t?t.name:""),n.save_changes(),f()}),b.addEventListener("click",()=>{E()}),v.addEventListener("change",()=>{C(),n.set("channel",Number(v.value)),n.save_changes()}),x.addEventListener("change",()=>{n.set("forward_notes",x.checked),n.save_changes()}),n.on("change:midi_port",f),n.on("change:channel",f),n.on("change:forward_notes",f),n.on("change:session_id",w),n.on("change:send_request",_),w(),f(),E();function A(){C(),r?.noteListeners&&(r.noteListeners=r.noteListeners.filter(e=>e!==g)),document.removeEventListener("nbplay-note",h),i.disconnect()}let N=S(n,A);return()=>{N(),A()}}var W={render:D};export{W as default};
//# sourceMappingURL=midi_output.js.map
