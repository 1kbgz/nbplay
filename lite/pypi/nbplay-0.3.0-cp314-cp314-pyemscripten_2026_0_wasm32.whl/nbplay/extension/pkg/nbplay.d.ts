/* tslint:disable */
/* eslint-disable */

/**
 * Web Audio output engine exposed to JavaScript via wasm-bindgen.
 */
export class WasmAudioOutput {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Whether audio is currently playing.
     */
    is_playing(): boolean;
    /**
     * Create a new audio output engine.
     */
    constructor();
    /**
     * Get the actual sample rate from the AudioContext.
     */
    sample_rate(): number;
    /**
     * Set the gain (amplitude). Only effective while playing.
     */
    set_gain(value: number): void;
    /**
     * Start playing an oscillator.
     * `osc_type`: "sine" | "square" | "saw" | "noise"
     */
    start(osc_type: string, frequency: number, amplitude: number, sample_rate: number): void;
    /**
     * Stop playback.
     */
    stop(): void;
}

/**
 * MIDI access handle backed by the Web MIDI API.
 */
export class WasmMidiAccess {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Get the number of available MIDI input ports.
     */
    input_port_count(): number;
    /**
     * List available MIDI input port names.
     */
    list_input_ports(): string[];
    /**
     * Request MIDI access from the browser.
     * Must be called from a user-gesture context in some browsers.
     */
    static new(): Promise<WasmMidiAccess>;
}

/**
 * List available audio output device info (returns sampleRate from AudioContext).
 */
export function default_sample_rate(): number;

/**
 * List available MIDI input port names (async – calls requestMIDIAccess).
 */
export function list_midi_ports(): Promise<any>;

/**
 * Parse raw MIDI bytes (from a MIDIMessageEvent.data) into a JSON-serializable
 * object.  Returns null if the bytes don't form a valid message.
 */
export function parse_midi_message(data: Uint8Array): any;

/**
 * Convenience: request MIDI access and return a WasmMidiAccess handle.
 */
export function request_midi_access(): Promise<WasmMidiAccess>;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_wasmaudiooutput_free: (a: number, b: number) => void;
    readonly __wbg_wasmmidiaccess_free: (a: number, b: number) => void;
    readonly parse_midi_message: (a: number, b: number) => any;
    readonly wasmaudiooutput_is_playing: (a: number) => number;
    readonly wasmaudiooutput_new: () => [number, number, number];
    readonly wasmaudiooutput_sample_rate: (a: number) => number;
    readonly wasmaudiooutput_set_gain: (a: number, b: number) => void;
    readonly wasmaudiooutput_start: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number];
    readonly wasmaudiooutput_stop: (a: number) => void;
    readonly wasmmidiaccess_input_port_count: (a: number) => number;
    readonly wasmmidiaccess_list_input_ports: (a: number) => [number, number];
    readonly wasmmidiaccess_new: () => any;
    readonly default_sample_rate: () => number;
    readonly list_midi_ports: () => any;
    readonly request_midi_access: () => any;
    readonly wasm_bindgen_578b2af46f5757c9___convert__closures_____invoke___wasm_bindgen_578b2af46f5757c9___JsValue__core_608f92abc48d28da___result__Result_____wasm_bindgen_578b2af46f5757c9___JsError___true_: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen_578b2af46f5757c9___convert__closures_____invoke___js_sys_1a8ff20977208ce8___Function_fn_wasm_bindgen_578b2af46f5757c9___JsValue_____wasm_bindgen_578b2af46f5757c9___sys__Undefined___js_sys_1a8ff20977208ce8___Function_fn_wasm_bindgen_578b2af46f5757c9___JsValue_____wasm_bindgen_578b2af46f5757c9___sys__Undefined_______true_: (a: number, b: number, c: any, d: any) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_destroy_closure: (a: number, b: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __externref_drop_slice: (a: number, b: number) => void;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
